plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.jawiclock"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.jawiclock"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "1.5"
    }
    // Kunci tetap supaya APK baru boleh dipasang di atas yang lama
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            storeType = "pkcs12"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
