package com.example.jawiclock

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

/** Rekod ralat dalam app supaya punca masalah (cth widget hilang di Android tertentu) boleh dilihat dan dihantar. */
object CrashLog {
    private const val MAX_CHARS = 20_000

    private fun file(ctx: Context) = File(ctx.filesDir, "ralat.txt")

    fun write(ctx: Context, where: String, t: Throwable) {
        try {
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            val entry = "[${Date()}] $where\n" +
                "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                "$sw\n------\n"
            val f = file(ctx)
            var text = (if (f.exists()) f.readText() else "") + entry
            if (text.length > MAX_CHARS) text = text.takeLast(MAX_CHARS)
            f.writeText(text)
        } catch (_: Throwable) {
        }
    }

    fun read(ctx: Context): String? = try {
        val f = file(ctx)
        if (f.exists() && f.length() > 0) f.readText() else null
    } catch (_: Throwable) {
        null
    }

    fun clear(ctx: Context) {
        try { file(ctx).delete() } catch (_: Throwable) {}
    }

    /** Catat ralat yang menyebabkan app terhenti, kemudian biarkan sistem uruskan seperti biasa. */
    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            write(app, "App terhenti (thread ${thread.name})", e)
            previous?.uncaughtException(thread, e)
        }
    }
}
