package com.example.jawiclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.widget.Toast

/** Tanpa paparan: dibuka dari notifikasi, minta pelancar letak semula widget (pengguna tekan "Tambah"). */
class RestoreActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, JawiWidget::class.java), null, null)
            Notif.cancelRestore(this)
        } else {
            Toast.makeText(
                this,
                "Pelancar tak sokong. Tekan lama skrin utama > Widget > Jam Jawi By Dienz.",
                Toast.LENGTH_LONG,
            ).show()
        }
        finish()
    }
}
