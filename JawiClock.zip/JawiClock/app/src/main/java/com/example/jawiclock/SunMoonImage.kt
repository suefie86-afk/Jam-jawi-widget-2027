package com.example.jawiclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/**
 * Gambar matahari / bulan sendiri yang dipilih pengguna dari telefon.
 * Disimpan dalam storan app sendiri (tiada kebenaran diperlukan).
 * Disimpan sebagai PNG supaya latar lutsinar gambar asal kekal —
 * kalau simpan sebagai JPEG, latar lutsinar akan jadi putih.
 * Sama untuk semua widget (macam fail azan), bukan ikut widget id.
 */
object SunMoonImage {
    private const val MAX_STORED = 512

    private fun file(ctx: Context, sun: Boolean) =
        File(ctx.filesDir, if (sun) "sun.png" else "moon.png")

    fun has(ctx: Context, sun: Boolean): Boolean {
        val f = file(ctx, sun)
        return f.exists() && f.length() > 0
    }

    fun importFrom(ctx: Context, sun: Boolean, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_STORED * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        // betulkan putaran gambar (EXIF)
        val orient = ctx.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        }
        val scale = minOf(1f, MAX_STORED.toFloat() / maxOf(bmp.width, bmp.height))
        m.postScale(scale, scale)
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)

        file(ctx, sun).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    } catch (e: Exception) {
        false
    }

    fun delete(ctx: Context, sun: Boolean) {
        file(ctx, sun).delete()
    }

    /** Gambar untuk widget, dikecilkan lagi supaya ringan (paling besar 256px). */
    fun render(ctx: Context, sun: Boolean): Bitmap? {
        val f = file(ctx, sun)
        if (!f.exists()) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
        return BitmapFactory.decodeFile(f.absolutePath, opts)
    }
}
