package com.example.jawiclock

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** Tetapan azan (sama untuk semua widget): hidup/mati dan fail audio pilihan pengguna. */
object Azan {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("jawi_azan", Context.MODE_PRIVATE)

    fun file(ctx: Context) = File(ctx.filesDir, "azan.audio")
    fun hasFile(ctx: Context) = file(ctx).exists() && file(ctx).length() > 0

    fun enabled(ctx: Context) = sp(ctx).getBoolean("on", false)
    fun setEnabled(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("on", on).apply()

    fun name(ctx: Context): String? = if (hasFile(ctx)) sp(ctx).getString("name", "Azan pilihan") else null

    /** Salin fail audio yang dipilih ke storan app (supaya boleh dimainkan walaupun app di belakang tabir). Pulangkan nama fail. */
    fun importFrom(ctx: Context, uri: Uri): String? = try {
        var name = "Azan pilihan"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        val tmp = File(ctx.filesDir, "azan.tmp")
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { input.copyTo(it) }
        } ?: throw IllegalStateException("tiada data")
        tmp.copyTo(file(ctx), overwrite = true)
        tmp.delete()
        sp(ctx).edit().putString("name", name).apply()
        name
    } catch (e: Exception) {
        null
    }
}
