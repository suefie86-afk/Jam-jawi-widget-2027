package com.example.jawiclock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/** Gambar latar widget yang dipilih dari telefon. Disimpan dalam storan app sendiri (tiada kebenaran diperlukan). */
object BgImage {
    private const val MAX_STORED = 1600
    private const val MAX_RENDER = 900f

    private class Cached(val key: String, val bmp: Bitmap)
    private val cache = HashMap<Int, Cached>()

    private fun file(ctx: Context, id: Int) = File(ctx.filesDir, "bg_$id.jpg")

    fun importFrom(ctx: Context, id: Int, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_STORED * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return false

        // betulkan putaran gambar (EXIF)
        val orient = ctx.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
        }
        val scale = minOf(1f, MAX_STORED.toFloat() / maxOf(bmp.width, bmp.height))
        m.postScale(scale, scale)
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)

        file(ctx, id).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        cache.remove(id)
        true
    } catch (e: Exception) {
        false
    }

    fun delete(ctx: Context, id: Int) {
        file(ctx, id).delete()
        cache.remove(id)
    }

    /**
     * Hasilkan gambar latar yang sudah dipotong (center-crop) ikut nisbah widget dan
     * bucu dibulatkan seperti latar asal. wDp/hDp = saiz widget semasa dalam dp (0 = tak diketahui).
     */
    fun render(ctx: Context, id: Int, wDp: Int, hDp: Int): Bitmap? {
        val f = file(ctx, id)
        if (!f.exists()) return null
        val d = ctx.resources.displayMetrics.density
        val ww = (if (wDp > 0) wDp else 360) * d
        val hh = (if (hDp > 0) hDp else 300) * d
        val sc = minOf(1f, MAX_RENDER / maxOf(ww, hh))
        val tw = (ww * sc).toInt().coerceAtLeast(64)
        val th = (hh * sc).toInt().coerceAtLeast(64)
        val key = "${f.lastModified()}-$tw-$th"
        cache[id]?.let { if (it.key == key) return it.bmp }

        val src = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        // center-crop
        val targetAspect = tw.toFloat() / th
        val srcAspect = src.width.toFloat() / src.height
        val srcRect = if (srcAspect > targetAspect) {
            val cw = (src.height * targetAspect).toInt()
            Rect((src.width - cw) / 2, 0, (src.width + cw) / 2, src.height)
        } else {
            val ch = (src.width / targetAspect).toInt()
            Rect(0, (src.height - ch) / 2, src.width, (src.height + ch) / 2)
        }
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val radius = 24f * d * sc // sama dengan bucu widget_bg (24dp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawRoundRect(RectF(0f, 0f, tw.toFloat(), th.toFloat()), radius, radius, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(src, srcRect, Rect(0, 0, tw, th), paint)
        src.recycle()
        cache[id] = Cached(key, out)
        return out
    }
}
