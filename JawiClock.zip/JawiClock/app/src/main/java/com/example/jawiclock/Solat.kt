package com.example.jawiclock

import android.content.Context
import android.text.Spannable
import android.text.SpannableString
import android.text.format.DateFormat
import android.text.style.RelativeSizeSpan
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Waktu solat rasmi JAKIM (e-solat.gov.my), disimpan sebagai cache harian. */
object Solat {
    private const val BASE =
        "https://www.e-solat.gov.my/index.php?r=esolatApi/takwimsolat&period=today&zone="
    private val KEYS = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")

    private fun sp(ctx: Context) = ctx.getSharedPreferences("jawi_solat", Context.MODE_PRIVATE)
    private fun today(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    /** Waktu hari ini (minit dalam hari: Subuh, Zohor, Asar, Maghrib, Isyak) atau null. */
    fun cached(ctx: Context, zone: String): List<Int>? {
        val v = sp(ctx).getString("t_$zone", null) ?: return null
        val parts = v.split("|")
        if (parts.size != 2 || parts[0] != today()) return null
        val mins = parts[1].split(",").mapNotNull { it.toIntOrNull() }
        return if (mins.size == 5) mins else null
    }

    /** Tarikh Hijri hari ini daripada JAKIM (tahun, bulan, hari) atau null kalau tiada. */
    fun cachedHijri(ctx: Context, zone: String): Triple<Int, Int, Int>? {
        if (zone.isBlank()) return null
        val v = sp(ctx).getString("h_$zone", null) ?: return null
        val parts = v.split("|")
        if (parts.size != 2 || parts[0] != today()) return null
        val n = parts[1].split("-").mapNotNull { it.toIntOrNull() }
        return if (n.size == 3 && n[1] in 1..12) Triple(n[0], n[1], n[2]) else null
    }

    /** Perlu ambil data baru? (cache lapuk dan percubaan terakhir lebih 15 minit lalu) */
    fun needsFetch(ctx: Context, zone: String): Boolean {
        if (zone.isBlank() || cached(ctx, zone) != null) return false
        val last = sp(ctx).getLong("try_$zone", 0L)
        return System.currentTimeMillis() - last > 15 * 60 * 1000L
    }

    /** Ambil dari JAKIM. JANGAN panggil di thread utama. Pulang null kalau berjaya, atau mesej ralat. */
    fun refresh(ctx: Context, zone: String): String? {
        sp(ctx).edit().putLong("try_$zone", System.currentTimeMillis()).apply()
        return try {
            doFetch(ctx, zone)
        } catch (e: Exception) {
            e.javaClass.simpleName + ": " + (e.message ?: "")
        }
    }

    private fun doFetch(ctx: Context, zone: String): String? {
        val conn = URL(BASE + zone).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JamJawi")
            if (conn.responseCode != 200) return "HTTP " + conn.responseCode
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(body).optJSONArray("prayerTime")
            if (arr == null || arr.length() == 0) return "Kod zon tidak sah"
            val o = arr.getJSONObject(0)

            val out = mutableListOf<Int>()
            for (k in KEYS) {
                var m = toMinutes(o.optString(k)) ?: return "Format waktu tidak dikenali"
                // kalau waktu diberi dalam format 12 jam, pastikan susunan menaik
                while (out.isNotEmpty() && m <= out.last()) m += 720
                out += m
            }
            val mins = out.map { it % 1440 }
            sp(ctx).edit().putString("t_$zone", today() + "|" + mins.joinToString(",")).apply()
            // Tarikh Hijri rasmi (JAKIM), kalau ada dalam jawapan
            val h = o.optString("hijri")
            if (Regex("\\d{4}-\\d{1,2}-\\d{1,2}").matches(h)) {
                sp(ctx).edit().putString("h_$zone", today() + "|" + h).apply()
            }
            return null
        } finally {
            conn.disconnect()
        }
    }

    private fun toMinutes(s: String): Int? {
        val m = Regex("(\\d{1,2}):(\\d{2})").find(s) ?: return null
        return m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
    }

    /** Format waktu solat. Mod 12 jam: AM/PM dipaparkan kecil di sebelah jam. */
    fun fmt(ctx: Context, minutes: Int): CharSequence {
        val h = minutes / 60
        val mm = minutes % 60
        if (DateFormat.is24HourFormat(ctx)) {
            return String.format(Locale.US, "%02d:%02d", h, mm)
        }
        val base = String.format(Locale.US, "%d:%02d", if (h % 12 == 0) 12 else h % 12, mm)
        val ampm = if (h < 12) "AM" else "PM"
        return SpannableString("$base $ampm").apply {
            setSpan(
                RelativeSizeSpan(0.6f),
                base.length + 1, length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
            )
        }
    }
}
