package com.example.jawiclock

/** Nama ringkas kawasan bagi kod zon JAKIM. Kod tak dikenali dipaparkan sebagai kod itu sendiri. */
object ZoneNames {
    private val names = mapOf(
        "JHR01" to "Pulau Aur, Pemanggil", "JHR02" to "Johor Bahru, Kota Tinggi",
        "JHR03" to "Kluang, Pontian", "JHR04" to "Batu Pahat, Muar",
        "KDH01" to "Kota Setar, Kubang Pasu", "KDH02" to "Kuala Muda, Yan",
        "KDH03" to "Padang Terap, Sik", "KDH04" to "Baling",
        "KDH05" to "Kulim, Bandar Baharu", "KDH06" to "Langkawi", "KDH07" to "Gunung Jerai",
        "KTN01" to "Kota Bharu, Bachok", "KTN03" to "Jeli, Gua Musang",
        "MLK01" to "Melaka",
        "NGS01" to "Tampin, Jempol", "NGS02" to "Jelebu, Kuala Pilah", "NGS03" to "Seremban, Port Dickson",
        "PHG01" to "Pulau Tioman", "PHG02" to "Kuantan, Pekan", "PHG03" to "Temerloh, Jerantut",
        "PHG04" to "Bentong, Raub", "PHG05" to "Genting Sempah, Janda Baik",
        "PHG06" to "Cameron Highlands",
        "PLS01" to "Kangar, Arau",
        "PNG01" to "Pulau Pinang",
        "PRK01" to "Tapah, Tanjung Malim", "PRK02" to "Ipoh, Kuala Kangsar",
        "PRK03" to "Grik, Lenggong", "PRK04" to "Temengor, Belum",
        "PRK05" to "Teluk Intan, Lumut", "PRK06" to "Taiping, Parit Buntar", "PRK07" to "Bukit Larut",
        "SBH01" to "Sandakan (Timur)", "SBH02" to "Beluran, Telupid", "SBH03" to "Lahad Datu, Semporna",
        "SBH04" to "Tawau", "SBH05" to "Kudat, Kota Marudu", "SBH06" to "Gunung Kinabalu",
        "SBH07" to "Kota Kinabalu, Ranau", "SBH08" to "Keningau, Tambunan", "SBH09" to "Beaufort, Sipitang",
        "SGR01" to "Gombak, Petaling", "SGR02" to "Kuala Selangor, Sabak Bernam", "SGR03" to "Klang, Kuala Langat",
        "SWK01" to "Limbang, Lawas", "SWK02" to "Miri, Marudi", "SWK03" to "Bintulu, Belaga",
        "SWK04" to "Sibu, Mukah", "SWK05" to "Sarikei, Matu", "SWK06" to "Sri Aman, Betong",
        "SWK07" to "Serian, Samarahan", "SWK08" to "Kuching, Bau", "SWK09" to "Kampung Patarikan",
        "TRG01" to "Kuala Terengganu, Marang", "TRG02" to "Besut, Setiu",
        "TRG03" to "Hulu Terengganu", "TRG04" to "Dungun, Kemaman",
        "WLY01" to "Kuala Lumpur, Putrajaya", "WLY02" to "Labuan",
    )

    fun name(zone: String): String = names[zone.uppercase()] ?: zone
}
