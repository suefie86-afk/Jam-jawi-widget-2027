package com.example.jawiclock

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class ConfigActivity : Activity() {
    private companion object {
        const val REQ_BG = 1001
        const val REQ_AZAN = 1002
        const val REQ_SUN = 1003
        const val REQ_MOON = 1004
    }

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var style = Style()
    private var azanLabel: TextView? = null
    private var sunLabel: TextView? = null
    private var moonLabel: TextView? = null
    private var azanTesting = false
    private lateinit var preview: FrameLayout
    private var previewRoot: View? = null
    private var selectedElement: ColorTarget? = null
    private var zoneEdit: EditText? = null
    private lateinit var controlsBox: LinearLayout
    private lateinit var secWarna: LinearLayout
    private lateinit var secSusun: LinearLayout
    private lateinit var secGrafik: LinearLayout
    private lateinit var secSolat: LinearLayout
    private val tabButtons = mutableListOf<Button>()
    private var currentTab = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val textColors = listOf(
        "#FFFFFF", "#39FF14", "#FFE600", "#FFF8E1", "#FFF176", "#FFEB3B", "#E6C86E", "#FFC107", "#FF9800",
        "#FF5722", "#F44336", "#FF1744", "#FF4081", "#F48FB1", "#E040FB", "#B388FF",
        "#7C4DFF", "#536DFE", "#2979FF", "#40C4FF", "#18FFFF", "#64FFDA", "#1DE9B6",
        "#00E676", "#76FF03", "#C6FF00", "#A5D6A7", "#90CAF9", "#BDBDBD", "#000000",
    ).map { Color.parseColor(it) }

    private val bgColors = listOf(
        "#0B3D2E", "#000000", "#1A237E", "#4E342E", "#37474F", "#FFFFFF", "#311B92",
        "#B71C1C", "#004D40", "#1B5E20", "#0D47A1", "#E65100", "#AD1457", "#6A1B9A",
        "#FFD600", "#00BCD4", "#00C853", "#FF4081", "#2979FF", "#FF6D00", "#E6C86E",
    ).map { Color.parseColor(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notif.askPermission(this)
        setResult(RESULT_CANCELED)

        widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID,
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        style = if (!Prefs.exists(this, widgetId) && Prefs.hasLast(this)) {
            // widget baru selepas yang lama terpadam: mula dengan tetapan terakhir
            BgImage.restoreLast(this, widgetId)
            Prefs.loadLast(this)
        } else {
            Prefs.load(this, widgetId)
        }

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
        }

        // Pratonton (latar kelabu supaya kesan lutsinar nampak)
        preview = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#3A4252"))
            setPadding(dp(16), dp(24), dp(16), dp(16))
            minimumHeight = dp(190)
        }
        outer.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Bar tab: Warna | Susun Atur | Grafik | Solat
        val tabBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        listOf("Warna", "Susun Atur", "Grafik", "Solat").forEachIndexed { i, name ->
            val b = Button(this).apply {
                text = name
                textSize = 13f
                setOnClickListener { showTab(i) }
            }
            tabButtons.add(b)
            tabBar.addView(b, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        outer.addView(tabBar)

        controlsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        buildSections()

        outer.addView(
            ScrollView(this).apply { addView(controlsBox) },
            LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f),
        )

        val save = Button(this)
        save.text = "Simpan"
        save.setOnClickListener {
            val zone = (zoneEdit?.text?.toString() ?: "").trim().uppercase()
            if (zone.isNotEmpty() && !Regex("[A-Z]{3}\\d{2}").matches(zone)) {
                Toast.makeText(this, "Kod zon tak sah. Contoh: WLY01", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (zone.isEmpty()) {
                finishSave("")
                return@setOnClickListener
            }
            save.isEnabled = false
            save.text = "Menyemak JAKIM..."
            Thread {
                val err = Solat.refresh(applicationContext, zone)
                runOnUiThread {
                    save.isEnabled = true
                    save.text = "Simpan"
                    when {
                        err == null -> finishSave(zone)
                        // Kod zon memang salah: minta betulkan
                        err == "Kod zon tidak sah" ->
                            Toast.makeText(this, "Kod zon tak sah. Semak di e-solat.gov.my", Toast.LENGTH_LONG).show()
                        // Tiada internet / JAKIM tak dapat dicapai: tetap simpan & pasang widget,
                        // waktu solat boleh dikemas kini kemudian dengan menekan widget.
                        else -> {
                            Toast.makeText(
                                this,
                                "Tiada sambungan. Widget dipasang, tekan widget nanti untuk kemas kini waktu solat.",
                                Toast.LENGTH_LONG,
                            ).show()
                            finishSave(zone)
                        }
                    }
                }
            }.start()
        }
        outer.addView(save, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            setMargins(dp(16), dp(8), dp(16), dp(16))
        })

        setContentView(outer)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_BG -> Thread {
                val ok = BgImage.importFrom(applicationContext, widgetId, uri)
                runOnUiThread {
                    if (ok) {
                        style = style.copy(bgImage = true)
                        refresh()
                    } else {
                        Toast.makeText(this, "Gagal membuka gambar", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
            REQ_AZAN -> Thread {
                val name = Azan.importFrom(applicationContext, uri)
                runOnUiThread {
                    if (name != null) {
                        updateAzanLabel()
                    } else {
                        Toast.makeText(this, "Gagal membuka fail audio", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
            REQ_SUN -> Thread {
                val ok = SunMoonImage.importFrom(applicationContext, true, uri)
                runOnUiThread {
                    if (ok) {
                        refresh()
                    } else {
                        Toast.makeText(this, "Gagal membuka gambar", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
            REQ_MOON -> Thread {
                val ok = SunMoonImage.importFrom(applicationContext, false, uri)
                runOnUiThread {
                    if (ok) {
                        refresh()
                    } else {
                        Toast.makeText(this, "Gagal membuka gambar", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    private fun updateSunMoonLabels() {
        sunLabel?.text = if (SunMoonImage.has(this, true)) "Gambar matahari: gambar sendiri" else "Gambar matahari: gambar asal"
        moonLabel?.text = if (SunMoonImage.has(this, false)) "Gambar bulan: gambar sendiri" else "Gambar bulan: gambar asal"
    }

    private fun updateAzanLabel() {
        val n = Azan.name(this)
        azanLabel?.text = if (n != null) "Fail azan: $n" else "Belum pilih fail azan"
    }

    override fun onDestroy() {
        if (azanTesting) AzanService.stop(this)
        super.onDestroy()
    }

    private fun buildSections() {
        // Simpan teks zon yang sedang ditaip supaya tak hilang bila seksyen dibina semula.
        val pendingZone = zoneEdit?.text?.toString()
        controlsBox.removeAllViews()
        secWarna = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        secSusun = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        secGrafik = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        secSolat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        controlsBox.addView(secWarna)
        controlsBox.addView(secSusun)
        controlsBox.addView(secGrafik)
        controlsBox.addView(secSolat)

        secWarna.addView(label("Sentuh untuk tukar warna"))
        secWarna.addView(TextView(this).apply {
            text = "Sentuh mana-mana tulisan pada preview widget di atas — Bismillah, jam besar, " +
                "tarikh, waktu solat dan lain-lain. Elemen yang disentuh akan dikelilingi kotak " +
                "garisan putus-putus, dan palet warna akan muncul. Warna berubah terus pada preview."
            setTextColor(Color.parseColor("#BBBBBB"))
            textSize = 13f
            setPadding(0, dp(2), 0, dp(6))
        })
        val warnaRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        warnaRow.addView(
            Button(this).apply {
                text = "Warna latar"
                setOnClickListener { openColorDialog(ColorTarget.BG) }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        warnaRow.addView(
            Button(this).apply {
                text = "Warna solat seterusnya"
                setOnClickListener { openColorDialog(ColorTarget.NEXT) }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        secWarna.addView(warnaRow)

        secGrafik.addView(label("Kotak sekeliling widget"))
        secGrafik.addView(
            CheckBox(this).apply {
                text = "Tunjukkan kotak sekeliling widget"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = style.frameEnabled
                setOnCheckedChangeListener { _, on ->
                    style = style.copy(frameEnabled = on)
                    refresh()
                }
            }
        )
        secGrafik.addView(label("Warna kotak"))
        secGrafik.addView(swatches(textColors, { style.frameColor }, { style = style.copy(frameColor = it) }))

        secGrafik.addView(label("Matahari / bulan"))
        secGrafik.addView(
            CheckBox(this).apply {
                text = "Tunjukkan matahari (7 pagi - 7 malam) / bulan (malam) sebelah jam"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = style.sunMoonEnabled
                setOnCheckedChangeListener { _, on ->
                    style = style.copy(sunMoonEnabled = on)
                    refresh()
                }
            }
        )

        // Dua tempat upload gambar sendiri: satu untuk matahari, satu untuk bulan.
        // Kalau tak upload, widget guna gambar asal (ic_sun / ic_moon).
        secGrafik.addView(label("Gambar matahari sendiri"))
        val sunTv = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#BDBDBD"))
        }
        sunLabel = sunTv
        secGrafik.addView(sunTv)
        val sunRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val sunPick = Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(i, "Pilih gambar matahari"), REQ_SUN)
            }
        }
        val sunClear = Button(this).apply {
            text = "Buang gambar"
            setOnClickListener {
                SunMoonImage.delete(this@ConfigActivity, true)
                refresh()
            }
        }
        sunRow.addView(sunPick, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        sunRow.addView(sunClear, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        secGrafik.addView(sunRow)

        secGrafik.addView(label("Gambar bulan sendiri"))
        val moonTv = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#BDBDBD"))
        }
        moonLabel = moonTv
        secGrafik.addView(moonTv)
        val moonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val moonPick = Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(i, "Pilih gambar bulan"), REQ_MOON)
            }
        }
        val moonClear = Button(this).apply {
            text = "Buang gambar"
            setOnClickListener {
                SunMoonImage.delete(this@ConfigActivity, false)
                refresh()
            }
        }
        moonRow.addView(moonPick, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        moonRow.addView(moonClear, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        secGrafik.addView(moonRow)

        secGrafik.addView(
            seek("Kelegapan latar", 100, style.bgAlpha, { if (it == 0) "Lutsinar" else "$it%" }) {
                style = style.copy(bgAlpha = it)
            }
        )
        secGrafik.addView(label("Gambar latar dari telefon"))
        val imgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pick = Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(i, "Pilih gambar latar"), REQ_BG)
            }
        }
        val clear = Button(this).apply {
            text = "Buang gambar"
            setOnClickListener {
                BgImage.delete(this@ConfigActivity, widgetId)
                style = style.copy(bgImage = false)
                refresh()
            }
        }
        imgRow.addView(pick, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        imgRow.addView(clear, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        secGrafik.addView(imgRow)
        secGrafik.addView(
            seek("Kelegapan gambar", 100, style.imgAlpha, { "$it%" }) {
                style = style.copy(imgAlpha = it)
            }
        )

        secSusun.addView(
            seek("Saiz jam besar", 150, style.clockScale - 50, { "${it + 50}%" }) {
                style = style.copy(clockScale = it + 50)
            }
        )
        secSusun.addView(
            seek("Saiz nama waktu solat", 150, style.nameScale - 50, { "${it + 50}%" }) {
                style = style.copy(nameScale = it + 50)
            }
        )
        secSusun.addView(
            seek("Saiz jam waktu solat", 150, style.timeScale - 50, { "${it + 50}%" }) {
                style = style.copy(timeScale = it + 50)
            }
        )
        secSusun.addView(
            seek("Saiz tulisan", 150, style.scale - 50, { "${it + 50}%" }) {
                style = style.copy(scale = it + 50)
            }
        )

        // Jarak antara baris bawah jam besar: -12 dp (tarik ke atas) hingga +24 dp (jauh ke bawah).
        // Slider 0..36, nilai sebenar = progress - 12.
        secSusun.addView(label("Jarak antara baris"))
        secSusun.addView(
            seek("Jarak jam besar ke jam Rumi", 36, style.gapTimePeriod + 12, { "${it - 12} dp" }) {
                style = style.copy(gapTimePeriod = it - 12)
            }
        )
        secSusun.addView(
            seek("Jarak jam Rumi ke Melaka", 36, style.gapPeriodLoc + 12, { "${it - 12} dp" }) {
                style = style.copy(gapPeriodLoc = it - 12)
            }
        )
        secSusun.addView(
            seek("Jarak Melaka ke tarikh Hijri", 36, style.gapLocDate + 12, { "${it - 12} dp" }) {
                style = style.copy(gapLocDate = it - 12)
            }
        )
        secSusun.addView(
            seek("Jarak tarikh Hijri ke tarikh Rumi", 36, style.gapDateDate2 + 12, { "${it - 12} dp" }) {
                style = style.copy(gapDateDate2 = it - 12)
            }
        )

        secSusun.addView(
            CheckBox(this).apply {
                text = "Padatkan widget (lebih pendek)"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = style.compact
                setOnCheckedChangeListener { _, on ->
                    style = style.copy(compact = on)
                    refresh()
                }
            }
        )
        secSusun.addView(TextView(this).apply {
            text = "Kurangkan jarak menegak antara elemen"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, dp(2), 0, dp(6))
        })

        // Azan (sama untuk semua widget)
        secSolat.addView(label("Azan"))
        secSolat.addView(
            CheckBox(this).apply {
                text = "Mainkan azan bila masuk waktu (guna alarm, berbunyi walaupun telefon senyap)"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = Azan.enabled(this@ConfigActivity)
                setOnCheckedChangeListener { _, on -> Azan.setEnabled(this@ConfigActivity, on) }
            }
        )
        secSolat.addView(
            CheckBox(this).apply {
                text = "Angkat telefon semasa azan = azan berhenti"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = Azan.pickupStop(this@ConfigActivity)
                setOnCheckedChangeListener { _, on -> Azan.setPickupStop(this@ConfigActivity, on) }
            }
        )
        val azanName = TextView(this).apply {
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }
        azanLabel = azanName
        updateAzanLabel()
        secSolat.addView(azanName)
        val azanRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        azanRow.addView(
            Button(this).apply {
                text = "Pilih azan"
                setOnClickListener {
                    val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "audio/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    startActivityForResult(Intent.createChooser(i, "Pilih fail azan"), REQ_AZAN)
                }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        azanRow.addView(
            Button(this).apply {
                text = "Cuba dengar"
                setOnClickListener {
                    if (Azan.hasFile(this@ConfigActivity)) {
                        azanTesting = true
                        AzanService.start(this@ConfigActivity)
                    } else {
                        Toast.makeText(this@ConfigActivity, "Pilih fail azan dulu", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        azanRow.addView(
            Button(this).apply {
                text = "Henti"
                setOnClickListener { AzanService.stop(this@ConfigActivity) }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        secSolat.addView(azanRow)
        secSolat.addView(
            seek("Kelantangan azan", 90, Azan.volume(this) - 10, { "${it + 10}%" }) {
                Azan.setVolume(this, it + 10)
                AzanService.applyVolume(this)
            }
        )
        secSolat.addView(
            Button(this).apply {
                text = "Uji notifikasi waktu solat"
                setOnClickListener {
                    val nm = getSystemService(android.app.NotificationManager::class.java)
                    if (!nm.areNotificationsEnabled()) {
                        Toast.makeText(
                            this@ConfigActivity,
                            "Notifikasi app ni dimatikan. Hidupkan di Setting > Apps > Jam Jawi By Dienz > Notifications.",
                            Toast.LENGTH_LONG,
                        ).show()
                    } else {
                        Notif.notifyPrayer(this@ConfigActivity, 1)
                    }
                }
            }
        )

        // Waktu solat JAKIM
        secSolat.addView(label("Kod zon JAKIM untuk waktu solat (kosongkan kalau tak mahu)"))
        val ze = EditText(this).apply {
            setText(pendingZone ?: style.zone)
            hint = "cth: WLY01"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#888888"))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setSingleLine()
        }
        zoneEdit = ze
        secSolat.addView(ze)
        secSolat.addView(TextView(this).apply {
            text = "Contoh: WLY01 (Kuala Lumpur & Putrajaya), SGR01 (Selangor: Gombak, Petaling, " +
                "Hulu Langat, Sepang, Hulu Selangor), PNG01 (Pulau Pinang), MLK01 (Melaka), " +
                "PLS01 (Perlis). Cari kod zon kawasan kamu di e-solat.gov.my. " +
                "Kalau tiada internet, widget tetap dipasang. Tekan widget nanti untuk kemas kini waktu solat."
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, dp(6), 0, dp(12))
        })

        showTab(currentTab)
    }

    private fun showTab(i: Int) {
        currentTab = i
        val secs = listOf(secWarna, secSusun, secGrafik, secSolat)
        secs.forEachIndexed { idx, s -> s.visibility = if (idx == i) View.VISIBLE else View.GONE }
        tabButtons.forEachIndexed { idx, b ->
            if (idx == i) {
                b.setBackgroundColor(Color.parseColor("#E6C86E"))
                b.setTextColor(Color.BLACK)
            } else {
                b.setBackgroundColor(Color.parseColor("#333333"))
                b.setTextColor(Color.WHITE)
            }
        }
    }

    private fun finishSave(zone: String) {
        style = style.copy(zone = zone)
        Prefs.save(this, widgetId, style)
        JawiWidget.updateAll(this)
        JawiWidget.schedule(this)
        setResult(
            RESULT_OK,
            Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId),
        )
        finish()
    }

    private fun refresh() {
        preview.removeAllViews()
        val rv = JawiWidget.build(this, widgetId, style)
        val rootView = rv.apply(this, preview)
        preview.addView(
            rootView,
            FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER),
        )
        attachTapTargets(rootView)
        updateSunMoonLabels()
    }

    // ---- Tap to Edit Color: sentuh elemen pada preview untuk tukar warnanya ----

    private enum class ColorTarget(
        val label: String,
        val get: (Style) -> Int,
        val set: (Style, Int) -> Style,
    ) {
        BISMILLAH("Bismillah", { it.bismillah }, { s, c -> s.copy(bismillah = c) }),
        CLOCK("Jam Jawi besar", { it.clock }, { s, c -> s.copy(clock = c) }),
        STDTIME("Jam biasa", { it.text }, { s, c -> s.copy(text = c) }),
        PERIOD("Siang / malam", { it.period }, { s, c -> s.copy(period = c) }),
        LOC("Nama lokasi", { it.loc }, { s, c -> s.copy(loc = c) }),
        HIJRI("Tarikh Hijrah", { it.hijri }, { s, c -> s.copy(hijri = c) }),
        LATIN("Tarikh Masihi", { it.date2 }, { s, c -> s.copy(date2 = c) }),
        PRAYER_NAME("Nama waktu solat", { it.prayerName }, { s, c -> s.copy(prayerName = c) }),
        PRAYER_TIME("Angka waktu solat", { it.prayerTime }, { s, c -> s.copy(prayerTime = c) }),
        FRAME("Bingkai widget", { it.frameColor }, { s, c -> s.copy(frameColor = c) }),
        DIVIDER("Garisan & ornamen", { it.divider }, { s, c -> s.copy(divider = c) }),
        BG("Warna latar", { it.bg }, { s, c -> s.copy(bg = c) }),
        NEXT("Solat seterusnya", { it.next }, { s, c -> s.copy(next = c) }),
    }

    private val PRAYER_NAME_IDS = intArrayOf(R.id.pn0, R.id.pn1, R.id.pn2, R.id.pn3, R.id.pn4)
    private val PRAYER_TIME_IDS = intArrayOf(R.id.pt0, R.id.pt1, R.id.pt2, R.id.pt3, R.id.pt4)
    private val DIVIDER_VIEW_IDS = intArrayOf(
        R.id.div_top, R.id.div, R.id.sep0, R.id.sep1, R.id.sep2, R.id.sep3,
    )

    private fun targetViews(root: View, t: ColorTarget): List<View> {
        fun find(id: Int): View? = root.findViewById(id)
        return when (t) {
            ColorTarget.BISMILLAH -> listOfNotNull(find(R.id.bismillah))
            ColorTarget.CLOCK -> listOfNotNull(find(R.id.time))
            ColorTarget.STDTIME -> listOfNotNull(find(R.id.stdtime))
            ColorTarget.PERIOD -> listOfNotNull(find(R.id.period))
            ColorTarget.LOC -> listOfNotNull(find(R.id.loc))
            ColorTarget.HIJRI -> listOfNotNull(find(R.id.date))
            ColorTarget.LATIN -> listOfNotNull(find(R.id.date2))
            ColorTarget.PRAYER_NAME -> PRAYER_NAME_IDS.map { find(it) }.filterNotNull()
            ColorTarget.PRAYER_TIME -> PRAYER_TIME_IDS.map { find(it) }.filterNotNull()
            ColorTarget.FRAME -> listOfNotNull(find(R.id.frame))
            ColorTarget.DIVIDER -> DIVIDER_VIEW_IDS.map { find(it) }.filterNotNull()
            // BG & NEXT tiada view pada preview: dibuka melalui butang dalam tab WARNA.
            ColorTarget.BG, ColorTarget.NEXT -> emptyList()
        }
    }

    /** Pasang sentuhan pada setiap elemen preview (dipanggil semula setiap kali preview dibina). */
    private fun attachTapTargets(root: View) {
        previewRoot = root
        for (t in ColorTarget.values()) {
            for (v in targetViews(root, t)) {
                v.setOnClickListener { openColorDialog(t) }
            }
        }
        // Kawasan kosong preview = bingkai (kotak hanya nampak bila dihidupkan di tab GRAFIK;
        // kalau kotak off, sentuhan ini sekadar ditelan supaya tidak tercetus refresh widget).
        root.setOnClickListener { openColorDialog(ColorTarget.FRAME) }
        applyHighlight()
    }

    private fun dashedHighlight() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(Color.TRANSPARENT)
        setStroke(dp(2), Color.parseColor("#FFD600"), dp(6).toFloat(), dp(4).toFloat())
    }

    /** Kotak garisan putus-putus pada elemen yang sedang dipilih — hanya dalam halaman tetapan. */
    private fun applyHighlight() {
        val root = previewRoot ?: return
        for (t in ColorTarget.values()) {
            val selected = (t == selectedElement)
            for (v in targetViews(root, t)) {
                v.background = if (selected) dashedHighlight() else null
            }
        }
    }

    /** Palet warna sebagai pop-up: pilih bulatan = terus tutup; slider pelangi = ubah live, tutup dengan "Selesai". */
    private fun openColorDialog(t: ColorTarget) {
        selectedElement = t
        applyHighlight()
        val palette = if (t == ColorTarget.BG) bgColors else textColors
        var dlg: AlertDialog? = null
        val view = swatches(palette, { t.get(style) }, { style = t.set(style, it) }) { dlg?.dismiss() }
        val padded = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(view)
        }
        dlg = AlertDialog.Builder(this)
            .setTitle("Warna ${t.label}")
            .setView(padded)
            .setPositiveButton("Selesai", null)
            .show()
    }


    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.parseColor("#DDDDDD"))
        textSize = 14f
        setPadding(0, dp(16), 0, dp(6))
    }

    private fun circle(color: Int, selected: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(
            dp(if (selected) 3 else 1),
            if (selected) Color.parseColor("#4FC3F7") else Color.parseColor("#66FFFFFF"),
        )
    }

    private fun swatches(
        colors: List<Int>,
        selected: () -> Int,
        onPick: (Int) -> Unit,
        onCirclePick: (() -> Unit)? = null,
    ): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val views = mutableListOf<View>()
        fun paint() {
            colors.forEachIndexed { i, c -> views[i].background = circle(c, c == selected()) }
        }
        colors.chunked(7).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { c ->
                val v = View(this)
                v.layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                    setMargins(0, 0, dp(8), dp(8))
                }
                v.setOnClickListener {
                    onPick(c)
                    paint()
                    refresh()
                    onCirclePick?.invoke()
                }
                row.addView(v)
                views += v
            }
            box.addView(row)
        }

        // Slider pelangi untuk warna lain
        val hsv = FloatArray(3)
        Color.colorToHSV(selected(), hsv)
        val rainbow = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        val hue = SeekBar(this)
        hue.max = 359
        hue.progress = hsv[0].toInt().coerceIn(0, 359)
        hue.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, rainbow).apply {
            cornerRadius = dp(8).toFloat()
        }
        hue.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    onPick(Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f)))
                    paint()
                    refresh()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        box.addView(TextView(this).apply {
            text = "Geser untuk warna lain"
            setTextColor(Color.parseColor("#999999"))
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        box.addView(hue, LinearLayout.LayoutParams(MATCH_PARENT, dp(28)))
        paint()
        return box
    }

    private fun seek(
        title: String,
        max: Int,
        start: Int,
        fmt: (Int) -> String,
        onChange: (Int) -> Unit,
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = label("$title: ${fmt(start)}")
        val s = SeekBar(this).apply {
            this.max = max
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    t.text = "$title: ${fmt(p)}"
                    onChange(p)
                    refresh()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        box.addView(t)
        box.addView(s)
        return box
    }
}
