package com.example.jawiclock

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class ConfigActivity : Activity() {
    private companion object {
        const val REQ_BG = 1001
        const val REQ_AZAN = 1002
    }

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var style = Style()
    private var azanLabel: TextView? = null
    private var azanTesting = false
    private lateinit var preview: FrameLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val textColors = listOf(
        "#FFFFFF", "#39FF14", "#FFE600", "#FFF8E1", "#FFF176", "#FFEB3B", "#E6C86E", "#FFC107", "#FF9800",
        "#FF5722", "#F44336", "#FF1744", "#FF4081", "#F48FB1", "#E040FB", "#B388FF",
        "#7C4DFF", "#536DFE", "#2979FF", "#40C4FF", "#18FFFF", "#64FFDA", "#1DE9B6",
        "#00E676", "#76FF03", "#C6FF00", "#A5D6A7", "#90CAF9", "#BDBDBD", "#000000",
    ).map { Color.parseColor(it) }

    private val bgColors = listOf(
        "#0B3D2E", "#000000", "#1A237E", "#4E342E", "#37474F", "#FFFFFF", "#311B92",
        "#B71C1C", "#004D40", "#1B5E20", "#0D47A1", "#E65100", "#AD1457", "#6A1B9A",
        "#FFD600", "#00BCD4", "#00C853", "#FF4081", "#2979FF", "#FF6D00", "#E6C86E",
    ).map { Color.parseColor(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notif.askPermission(this)
        setResult(RESULT_CANCELED)

        widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID,
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        style = if (!Prefs.exists(this, widgetId) && Prefs.hasLast(this)) {
            // widget baru selepas yang lama terpadam: mula dengan tetapan terakhir
            BgImage.restoreLast(this, widgetId)
            Prefs.loadLast(this)
        } else {
            Prefs.load(this, widgetId)
        }

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
        }

        // Pratonton (latar kelabu supaya kesan lutsinar nampak)
        preview = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#3A4252"))
            setPadding(dp(16), dp(24), dp(16), dp(16))
            minimumHeight = dp(190)
        }
        outer.addView(preview, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }

        controls.addView(label("Warna jam besar"))
        controls.addView(swatches(textColors, { style.clock }) { style = style.copy(clock = it) })

        controls.addView(label("Warna jam biasa & waktu solat (putih)"))
        controls.addView(swatches(textColors, { style.text }) { style = style.copy(text = it) })

        controls.addView(label("Warna tarikh rumi"))
        controls.addView(swatches(textColors, { style.date2 }) { style = style.copy(date2 = it) })

        controls.addView(label("Warna bismillah, tarikh Jawi & nama waktu (emas)"))
        controls.addView(swatches(textColors, { style.accent }) { style = style.copy(accent = it) })

        controls.addView(label("Warna waktu solat seterusnya (hijau)"))
        controls.addView(swatches(textColors, { style.next }) { style = style.copy(next = it) })

        controls.addView(label("Warna latar"))
        controls.addView(swatches(bgColors, { style.bg }) { style = style.copy(bg = it) })

        controls.addView(label("Kotak sekeliling widget"))
        controls.addView(
            CheckBox(this).apply {
                text = "Tunjukkan kotak sekeliling widget"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = style.frameEnabled
                setOnCheckedChangeListener { _, on ->
                    style = style.copy(frameEnabled = on)
                    refresh()
                }
            }
        )
        controls.addView(label("Warna kotak"))
        controls.addView(swatches(textColors, { style.frameColor }) { style = style.copy(frameColor = it) })

        controls.addView(
            seek("Kelegapan latar", 100, style.bgAlpha, { if (it == 0) "Lutsinar" else "$it%" }) {
                style = style.copy(bgAlpha = it)
            }
        )
        controls.addView(label("Gambar latar dari telefon"))
        val imgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pick = Button(this).apply {
            text = "Pilih gambar"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(i, "Pilih gambar latar"), REQ_BG)
            }
        }
        val clear = Button(this).apply {
            text = "Buang gambar"
            setOnClickListener {
                BgImage.delete(this@ConfigActivity, widgetId)
                style = style.copy(bgImage = false)
                refresh()
            }
        }
        imgRow.addView(pick, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        imgRow.addView(clear, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        controls.addView(imgRow)
        controls.addView(
            seek("Kelegapan gambar", 100, style.imgAlpha, { "$it%" }) {
                style = style.copy(imgAlpha = it)
            }
        )

        controls.addView(
            seek("Saiz jam besar", 150, style.clockScale - 50, { "${it + 50}%" }) {
                style = style.copy(clockScale = it + 50)
            }
        )
        controls.addView(
            seek("Saiz nama waktu solat", 150, style.nameScale - 50, { "${it + 50}%" }) {
                style = style.copy(nameScale = it + 50)
            }
        )
        controls.addView(
            seek("Saiz jam waktu solat", 150, style.timeScale - 50, { "${it + 50}%" }) {
                style = style.copy(timeScale = it + 50)
            }
        )
        controls.addView(
            seek("Saiz tulisan", 150, style.scale - 50, { "${it + 50}%" }) {
                style = style.copy(scale = it + 50)
            }
        )

        // Azan (sama untuk semua widget)
        controls.addView(label("Azan"))
        controls.addView(
            CheckBox(this).apply {
                text = "Mainkan azan bila masuk waktu (guna alarm, berbunyi walaupun telefon senyap)"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = Azan.enabled(this@ConfigActivity)
                setOnCheckedChangeListener { _, on -> Azan.setEnabled(this@ConfigActivity, on) }
            }
        )
        controls.addView(
            CheckBox(this).apply {
                text = "Angkat telefon semasa azan = azan berhenti"
                textSize = 15f
                setTextColor(Color.WHITE)
                isChecked = Azan.pickupStop(this@ConfigActivity)
                setOnCheckedChangeListener { _, on -> Azan.setPickupStop(this@ConfigActivity, on) }
            }
        )
        val azanName = TextView(this).apply {
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }
        azanLabel = azanName
        updateAzanLabel()
        controls.addView(azanName)
        val azanRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        azanRow.addView(
            Button(this).apply {
                text = "Pilih azan"
                setOnClickListener {
                    val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "audio/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    startActivityForResult(Intent.createChooser(i, "Pilih fail azan"), REQ_AZAN)
                }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        azanRow.addView(
            Button(this).apply {
                text = "Cuba dengar"
                setOnClickListener {
                    if (Azan.hasFile(this@ConfigActivity)) {
                        azanTesting = true
                        AzanService.start(this@ConfigActivity)
                    } else {
                        Toast.makeText(this@ConfigActivity, "Pilih fail azan dulu", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        azanRow.addView(
            Button(this).apply {
                text = "Henti"
                setOnClickListener { AzanService.stop(this@ConfigActivity) }
            },
            LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f),
        )
        controls.addView(azanRow)
        controls.addView(
            seek("Kelantangan azan", 90, Azan.volume(this) - 10, { "${it + 10}%" }) {
                Azan.setVolume(this, it + 10)
                AzanService.applyVolume(this)
            }
        )
        controls.addView(
            Button(this).apply {
                text = "Uji notifikasi waktu solat"
                setOnClickListener {
                    val nm = getSystemService(android.app.NotificationManager::class.java)
                    if (!nm.areNotificationsEnabled()) {
                        Toast.makeText(
                            this@ConfigActivity,
                            "Notifikasi app ni dimatikan. Hidupkan di Setting > Apps > Jam Jawi By Dienz > Notifications.",
                            Toast.LENGTH_LONG,
                        ).show()
                    } else {
                        Notif.notifyPrayer(this@ConfigActivity, 1)
                    }
                }
            }
        )

        // Waktu solat JAKIM
        controls.addView(label("Kod zon JAKIM untuk waktu solat (kosongkan kalau tak mahu)"))
        val zoneEdit = EditText(this).apply {
            setText(style.zone)
            hint = "cth: WLY01"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#888888"))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setSingleLine()
        }
        controls.addView(zoneEdit)
        controls.addView(TextView(this).apply {
            text = "Contoh: WLY01 (Kuala Lumpur & Putrajaya), SGR01 (Selangor: Gombak, Petaling, " +
                "Hulu Langat, Sepang, Hulu Selangor), PNG01 (Pulau Pinang), MLK01 (Melaka), " +
                "PLS01 (Perlis). Cari kod zon kawasan kamu di e-solat.gov.my. " +
                "Kalau tiada internet, widget tetap dipasang. Tekan widget nanti untuk kemas kini waktu solat."
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, dp(6), 0, dp(12))
        })

        outer.addView(
            ScrollView(this).apply { addView(controls) },
            LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f),
        )

        val save = Button(this)
        save.text = "Simpan"
        save.setOnClickListener {
            val zone = zoneEdit.text.toString().trim().uppercase()
            if (zone.isNotEmpty() && !Regex("[A-Z]{3}\\d{2}").matches(zone)) {
                Toast.makeText(this, "Kod zon tak sah. Contoh: WLY01", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (zone.isEmpty()) {
                finishSave("")
                return@setOnClickListener
            }
            save.isEnabled = false
            save.text = "Menyemak JAKIM..."
            Thread {
                val err = Solat.refresh(applicationContext, zone)
                runOnUiThread {
                    save.isEnabled = true
                    save.text = "Simpan"
                    when {
                        err == null -> finishSave(zone)
                        // Kod zon memang salah: minta betulkan
                        err == "Kod zon tidak sah" ->
                            Toast.makeText(this, "Kod zon tak sah. Semak di e-solat.gov.my", Toast.LENGTH_LONG).show()
                        // Tiada internet / JAKIM tak dapat dicapai: tetap simpan & pasang widget,
                        // waktu solat boleh dikemas kini kemudian dengan menekan widget.
                        else -> {
                            Toast.makeText(
                                this,
                                "Tiada sambungan. Widget dipasang, tekan widget nanti untuk kemas kini waktu solat.",
                                Toast.LENGTH_LONG,
                            ).show()
                            finishSave(zone)
                        }
                    }
                }
            }.start()
        }
        outer.addView(save, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            setMargins(dp(16), dp(8), dp(16), dp(16))
        })

        setContentView(outer)
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_BG -> Thread {
                val ok = BgImage.importFrom(applicationContext, widgetId, uri)
                runOnUiThread {
                    if (ok) {
                        style = style.copy(bgImage = true)
                        refresh()
                    } else {
                        Toast.makeText(this, "Gagal membuka gambar", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
            REQ_AZAN -> Thread {
                val name = Azan.importFrom(applicationContext, uri)
                runOnUiThread {
                    if (name != null) {
                        updateAzanLabel()
                    } else {
                        Toast.makeText(this, "Gagal membuka fail audio", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }

    private fun updateAzanLabel() {
        val n = Azan.name(this)
        azanLabel?.text = if (n != null) "Fail azan: $n" else "Belum pilih fail azan"
    }

    override fun onDestroy() {
        if (azanTesting) AzanService.stop(this)
        super.onDestroy()
    }

    private fun finishSave(zone: String) {
        style = style.copy(zone = zone)
        Prefs.save(this, widgetId, style)
        JawiWidget.updateAll(this)
        JawiWidget.schedule(this)
        setResult(
            RESULT_OK,
            Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId),
        )
        finish()
    }

    private fun refresh() {
        preview.removeAllViews()
        val rv = JawiWidget.build(this, widgetId, style)
        preview.addView(
            rv.apply(this, preview),
            FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER),
        )
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.parseColor("#DDDDDD"))
        textSize = 14f
        setPadding(0, dp(16), 0, dp(6))
    }

    private fun circle(color: Int, selected: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(
            dp(if (selected) 3 else 1),
            if (selected) Color.parseColor("#4FC3F7") else Color.parseColor("#66FFFFFF"),
        )
    }

    private fun swatches(colors: List<Int>, selected: () -> Int, onPick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val views = mutableListOf<View>()
        fun paint() {
            colors.forEachIndexed { i, c -> views[i].background = circle(c, c == selected()) }
        }
        colors.chunked(7).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { c ->
                val v = View(this)
                v.layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                    setMargins(0, 0, dp(8), dp(8))
                }
                v.setOnClickListener {
                    onPick(c)
                    paint()
                    refresh()
                }
                row.addView(v)
                views += v
            }
            box.addView(row)
        }

        // Slider pelangi untuk warna lain
        val hsv = FloatArray(3)
        Color.colorToHSV(selected(), hsv)
        val rainbow = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        val hue = SeekBar(this)
        hue.max = 359
        hue.progress = hsv[0].toInt().coerceIn(0, 359)
        hue.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, rainbow).apply {
            cornerRadius = dp(8).toFloat()
        }
        hue.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    onPick(Color.HSVToColor(floatArrayOf(p.toFloat(), 1f, 1f)))
                    paint()
                    refresh()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        box.addView(TextView(this).apply {
            text = "Geser untuk warna lain"
            setTextColor(Color.parseColor("#999999"))
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        })
        box.addView(hue, LinearLayout.LayoutParams(MATCH_PARENT, dp(28)))
        paint()
        return box
    }

    private fun seek(
        title: String,
        max: Int,
        start: Int,
        fmt: (Int) -> String,
        onChange: (Int) -> Unit,
    ): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = label("$title: ${fmt(start)}")
        val s = SeekBar(this).apply {
            this.max = max
            progress = start
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    t.text = "$title: ${fmt(p)}"
                    onChange(p)
                    refresh()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        box.addView(t)
        box.addView(s)
        return box
    }
}
