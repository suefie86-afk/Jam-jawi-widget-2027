package com.example.jawiclock

import android.app.Application

class JawiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
