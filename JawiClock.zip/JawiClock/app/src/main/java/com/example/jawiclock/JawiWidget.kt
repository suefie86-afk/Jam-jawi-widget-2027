package com.example.jawiclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.AlarmClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class JawiWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(ctx)
        schedule(ctx)
    }

    override fun onAppWidgetOptionsChanged(
        ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: android.os.Bundle,
    ) {
        super.onAppWidgetOptionsChanged(ctx, mgr, id, newOptions)
        updateAll(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach {
            Prefs.delete(ctx, it)
            BgImage.delete(ctx, it)
        }
    }

    override fun onEnabled(ctx: Context) = schedule(ctx)

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pendingTick(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_TICK) checkPrayer(ctx)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                updateAll(ctx)
                schedule(ctx)
            }
        }
        refreshStale(ctx)
    }

    /** Getar telefon bila masuk waktu solat (semakan setiap minit melalui tick). */
    private fun checkPrayer(ctx: Context) {
        val ids = AppWidgetManager.getInstance(ctx)
            .getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
        val zones = ids.map { Prefs.load(ctx, it).zone }.filter { it.isNotBlank() }.distinct()
        if (zones.isEmpty()) return
        val now = Calendar.getInstance()
        val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(now.time)
        val sp = ctx.getSharedPreferences("jawi_vibrate", Context.MODE_PRIVATE)
        for (z in zones) {
            val mins = Solat.cached(ctx, z) ?: continue
            for (i in 0..4) {
                val diff = nowMin - mins[i]
                val key = "$day-${mins[i]}"
                // masuk waktu (bagi lencongan 1 minit kalau alarm lewat), getar sekali sahaja
                if (diff in 0..1 && sp.getString("last", "") != key) {
                    sp.edit().putString("last", key).apply()
                    vibrate(ctx)
                    Notif.notifyPrayer(ctx, i)
                    return
                }
            }
        }
    }

    private fun vibrate(ctx: Context) {
        val v = ctx.getSystemService(Vibrator::class.java) ?: return
        if (!v.hasVibrator()) return
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 250, 600, 250, 900), -1))
    }

    /** Ambil waktu solat baru dari JAKIM (di thread lain) kalau cache hari ini belum ada. */
    private fun refreshStale(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
        val zones = ids.map { Prefs.load(ctx, it).zone }
            .filter { it.isNotBlank() }
            .distinct()
            .filter { Solat.needsFetch(ctx, it) }
        if (zones.isEmpty()) return

        val pending = goAsync()
        val app = ctx.applicationContext
        Thread {
            try {
                zones.forEach { Solat.refresh(app, it) }
                updateAll(app)
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        private const val ACTION_TICK = "com.example.jawiclock.TICK"
        private const val ACTION_NOOP = "com.example.jawiclock.NOOP"

        private val NAME_IDS = intArrayOf(R.id.pn0, R.id.pn1, R.id.pn2, R.id.pn3, R.id.pn4)
        private val TIME_IDS = intArrayOf(R.id.pt0, R.id.pt1, R.id.pt2, R.id.pt3, R.id.pt4)

        /** Bina paparan widget ikut gaya. Dipakai juga untuk pratonton dalam ConfigActivity. */
        fun build(ctx: Context, id: Int, st: Style, now: Calendar = Calendar.getInstance()): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_jawi)
            rv.setTextViewText(R.id.time, Jawi.time(now))
            rv.setTextViewText(R.id.period, Jawi.period(now))
            rv.setTextViewText(R.id.date, Jawi.date(now))
            rv.setTextViewText(R.id.date2, Jawi.dateLatin(now))

            // Jam standard (angka biasa) di bawah tarikh
            val fmt = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
            rv.setTextViewText(R.id.stdtime, SimpleDateFormat(fmt, Locale.US).format(now.time))

            // Skala automatik ikut saiz widget (rujukan reka bentuk 280 x 270 dp)
            val opts = AppWidgetManager.getInstance(ctx).getAppWidgetOptions(id)
            val w = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            val h = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            val auto = if (w > 0 && h > 0) minOf(w / 280f, h / 270f).coerceIn(0.6f, 1.5f) else 1f
            val k = st.scale / 100f * auto
            rv.setTextViewTextSize(R.id.bismillah, TypedValue.COMPLEX_UNIT_SP, 15f * k)
            // Jam besar: saiz sendiri (kc). Fon Arab ada ruang kosong besar di atas angka dan di bawahnya,
            // jadi kotak jam dikecilkan & dinaikkan supaya jam rapat dengan hiasan dan baris di bawahnya.
            // Semua ukuran dalam unit "em" (= saiz fon jam) supaya sentiasa berskala dengan saiz jam.
            val kc = k * st.clockScale / 100f
            val em = 104f * kc
            rv.setTextViewTextSize(R.id.time, TypedValue.COMPLEX_UNIT_SP, em)
            if (Build.VERSION.SDK_INT >= 31) {
                rv.setViewLayoutHeight(R.id.time, 1.34f * em, TypedValue.COMPLEX_UNIT_SP)
                rv.setViewLayoutMargin(R.id.time, RemoteViews.MARGIN_TOP, -0.18f * em, TypedValue.COMPLEX_UNIT_SP)
            }
            rv.setTextViewTextSize(R.id.period, TypedValue.COMPLEX_UNIT_SP, 20f * k)
            rv.setTextViewTextSize(R.id.date, TypedValue.COMPLEX_UNIT_SP, 13f * k)
            rv.setTextViewTextSize(R.id.date2, TypedValue.COMPLEX_UNIT_SP, 14f * k)
            rv.setTextViewTextSize(R.id.loc, TypedValue.COMPLEX_UNIT_SP, 11f * k)
            rv.setTextViewTextSize(R.id.stdtime, TypedValue.COMPLEX_UNIT_SP, 14f * k)

            rv.setTextColor(R.id.time, st.clock)
            rv.setTextColor(R.id.stdtime, st.text)
            rv.setTextColor(R.id.date2, st.date2)
            rv.setTextColor(R.id.bismillah, st.accent)
            rv.setTextColor(R.id.date, st.accent)
            rv.setTextColor(R.id.loc, st.accent)
            rv.setTextViewText(R.id.loc, if (st.zone.isBlank()) "" else ZoneNames.name(st.zone))
            rv.setTextColor(R.id.period, st.accent)

            // Waktu solat JAKIM
            if (st.zone.isBlank()) {
                rv.setViewVisibility(R.id.prayers, View.GONE)
                rv.setViewVisibility(R.id.div, View.GONE)
                rv.setViewVisibility(R.id.loc, View.GONE)
            } else {
                rv.setViewVisibility(R.id.prayers, View.VISIBLE)
                rv.setViewVisibility(R.id.div, View.VISIBLE)
                rv.setViewVisibility(R.id.loc, View.VISIBLE)
                val mins = Solat.cached(ctx, st.zone)
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                // waktu seterusnya diserlahkan; lepas Isyak, serlahkan Subuh
                val next = if (mins == null) -1 else mins.indexOfFirst { it > nowMin }.let { if (it < 0) 0 else it }
                for (i in 0..4) {
                    rv.setTextViewText(NAME_IDS[i], Jawi.prayerNames[i])
                    rv.setTextViewText(TIME_IDS[i], mins?.let { Solat.fmt(ctx, it[i]) } ?: "--:--")
                    // hijau hanya untuk waktu seterusnya
                    rv.setTextColor(NAME_IDS[i], if (i == next) st.next else st.accent)
                    rv.setTextColor(TIME_IDS[i], if (i == next) st.next else st.text)
                    rv.setTextViewTextSize(NAME_IDS[i], TypedValue.COMPLEX_UNIT_SP, 13f * k)
                    rv.setTextViewTextSize(TIME_IDS[i], TypedValue.COMPLEX_UNIT_SP, 12f * k)
                }
            }

            // Bingkai hiasan (boleh disembunyikan dalam tetapan)
            rv.setViewVisibility(R.id.frame, if (st.showFrame) View.VISIBLE else View.GONE)
            for (fid in intArrayOf(R.id.frame_border, R.id.frame_c1, R.id.frame_c2, R.id.frame_c3, R.id.frame_c4)) {
                rv.setInt(fid, "setColorFilter", st.frame)
            }
            val pad = ((if (st.showFrame) 14 else 6) * ctx.resources.displayMetrics.density).toInt()
            rv.setViewPadding(R.id.content, pad, pad, pad, pad)

            val img = if (st.bgImage) BgImage.render(ctx, id, w, h) else null
            if (img != null) {
                // gambar latar dari telefon
                rv.setImageViewBitmap(R.id.bg, img)
                // Pelancar guna semula paparan lama, jadi penapis warna latar sebelum ini
                // masih melekat dan mewarnakan gambar jadi sekata. Kosongkan dulu.
                rv.setInt(R.id.bg, "setColorFilter", 0)
                rv.setFloat(R.id.bg, "setAlpha", st.imgAlpha / 100f)
            } else {
                // pulihkan latar warna asal (kalau sebelum ini gambar yang dipaparkan)
                rv.setImageViewResource(R.id.bg, R.drawable.widget_bg)
                rv.setInt(R.id.bg, "setColorFilter", st.bg)
                rv.setFloat(R.id.bg, "setAlpha", st.bgAlpha / 100f)
            }

            // Sentuh widget = tiada apa-apa. Tanpa pengendali sentuhan, sesetengah pelancar
            // membuka app bila widget disentuh, jadi dipasang tindakan kosong (NOOP) untuk
            // menelan sentuhan itu. Tetapan dibuka melalui ikon pensel pada pelancar
            // (tekan lama widget) - lihat widgetFeatures="reconfigurable".
            val noop = PendingIntent.getBroadcast(
                ctx, 0,
                Intent(ctx, JawiWidget::class.java).setAction(ACTION_NOOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.root, noop)

            // Tekan jam besar = buka app Jam telefon (senarai penggera)
            val openClock = PendingIntent.getActivity(
                ctx, 1,
                Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.time, openClock)
            return rv
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
            val now = Calendar.getInstance()
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx, id, Prefs.load(ctx, id), now))
            }
        }

        private fun pendingTick(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, JawiWidget::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        // Kejutkan widget pada permulaan setiap minit
        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val next = Calendar.getInstance().apply {
                add(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val pi = pendingTick(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            }
        }
    }
}
