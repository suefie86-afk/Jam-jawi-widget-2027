package com.example.jawiclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class JawiWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(ctx)
        schedule(ctx)
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { Prefs.delete(ctx, it) }
    }

    override fun onEnabled(ctx: Context) = schedule(ctx)

    override fun onDisabled(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pendingTick(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                updateAll(ctx)
                schedule(ctx)
            }
        }
        refreshStale(ctx)
    }

    /** Ambil waktu solat baru dari JAKIM (di thread lain) kalau cache hari ini belum ada. */
    private fun refreshStale(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
        val zones = ids.map { Prefs.load(ctx, it).zone }
            .filter { it.isNotBlank() }
            .distinct()
            .filter { Solat.needsFetch(ctx, it) }
        if (zones.isEmpty()) return

        val pending = goAsync()
        val app = ctx.applicationContext
        Thread {
            try {
                zones.forEach { Solat.refresh(app, it) }
                updateAll(app)
            } finally {
                pending.finish()
            }
        }.start()
    }

    companion object {
        private const val ACTION_TICK = "com.example.jawiclock.TICK"

        private val NAME_IDS = intArrayOf(R.id.pn0, R.id.pn1, R.id.pn2, R.id.pn3, R.id.pn4)
        private val TIME_IDS = intArrayOf(R.id.pt0, R.id.pt1, R.id.pt2, R.id.pt3, R.id.pt4)

        /** Bina paparan widget ikut gaya. Dipakai juga untuk pratonton dalam ConfigActivity. */
        fun build(ctx: Context, id: Int, st: Style, now: Calendar = Calendar.getInstance()): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_jawi)
            rv.setTextViewText(R.id.time, Jawi.time(now))
            rv.setTextViewText(R.id.period, Jawi.period(now))
            rv.setTextViewText(R.id.date, Jawi.date(now))

            // Jam standard (angka biasa) di bawah tarikh
            val fmt = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
            rv.setTextViewText(R.id.stdtime, SimpleDateFormat(fmt, Locale.US).format(now.time))

            val k = st.scale / 100f
            rv.setTextViewTextSize(R.id.bismillah, TypedValue.COMPLEX_UNIT_SP, 20f * k)
            rv.setTextViewTextSize(R.id.time, TypedValue.COMPLEX_UNIT_SP, 48f * k)
            rv.setTextViewTextSize(R.id.period, TypedValue.COMPLEX_UNIT_SP, 20f * k)
            rv.setTextViewTextSize(R.id.date, TypedValue.COMPLEX_UNIT_SP, 15f * k)
            rv.setTextViewTextSize(R.id.stdtime, TypedValue.COMPLEX_UNIT_SP, 13f * k)

            rv.setTextColor(R.id.time, st.text)
            rv.setTextColor(R.id.date, st.text)
            rv.setTextColor(R.id.stdtime, st.text)
            rv.setTextColor(R.id.bismillah, st.accent)
            rv.setTextColor(R.id.period, st.accent)

            // Waktu solat JAKIM
            if (st.zone.isBlank()) {
                rv.setViewVisibility(R.id.prayers, View.GONE)
            } else {
                rv.setViewVisibility(R.id.prayers, View.VISIBLE)
                val mins = Solat.cached(ctx, st.zone)
                val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                // waktu seterusnya diserlahkan; lepas Isyak, serlahkan Subuh
                val next = if (mins == null) -1 else mins.indexOfFirst { it > nowMin }.let { if (it < 0) 0 else it }
                for (i in 0..4) {
                    rv.setTextViewText(NAME_IDS[i], Jawi.prayerNames[i])
                    rv.setTextViewText(TIME_IDS[i], mins?.let { Solat.fmt(ctx, it[i]) } ?: "--:--")
                    val c = if (i == next) st.accent else st.text
                    rv.setTextColor(NAME_IDS[i], c)
                    rv.setTextColor(TIME_IDS[i], c)
                    rv.setTextViewTextSize(NAME_IDS[i], TypedValue.COMPLEX_UNIT_SP, 13f * k)
                    rv.setTextViewTextSize(TIME_IDS[i], TypedValue.COMPLEX_UNIT_SP, 12f * k)
                }
            }

            rv.setInt(R.id.bg, "setColorFilter", st.bg)
            rv.setFloat(R.id.bg, "setAlpha", st.bgAlpha / 100f)

            // Tekan widget = buka tetapan warna & saiz
            val cfg = Intent(ctx, ConfigActivity::class.java)
                .setAction(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(
                ctx, id, cfg,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.root, pi)
            return rv
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, JawiWidget::class.java))
            val now = Calendar.getInstance()
            for (id in ids) {
                mgr.updateAppWidget(id, build(ctx, id, Prefs.load(ctx, id), now))
            }
        }

        private fun pendingTick(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, JawiWidget::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        // Kejutkan widget pada permulaan setiap minit
        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            val next = Calendar.getInstance().apply {
                add(Calendar.MINUTE, 1)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val pi = pendingTick(ctx)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, next, pi)
            }
        }
    }
}
