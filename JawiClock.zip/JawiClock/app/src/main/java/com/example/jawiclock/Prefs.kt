package com.example.jawiclock

import android.content.Context
import android.graphics.Color

data class Style(
    val text: Int = Color.WHITE,                    // putih: jam & waktu solat
    val clock: Int = Color.parseColor("#FFE600"),   // warna jam besar
    val date2: Int = Color.WHITE,                   // warna tarikh rumi
    val accent: Int = Color.parseColor("#E6C86E"),  // emas: bismillah, tarikh Jawi & nama waktu
    val next: Int = Color.parseColor("#39FF14"),    // hijau neon: waktu solat seterusnya
    val bg: Int = Color.parseColor("#0B3D2E"),      // warna latar
    val bgImage: Boolean = false,                   // guna gambar dari telefon sebagai latar
    val imgAlpha: Int = 100,                        // kelegapan gambar latar, peratus
    val bgAlpha: Int = 0,                           // 0 = lutsinar, 100 = pekat
    val clockScale: Int = 100,                      // saiz jam besar sahaja, peratus
    val scale: Int = 100,                           // saiz tulisan, peratus
    val zone: String = "",                          // kod zon JAKIM, kosong = tiada waktu solat
)

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("jawi_style", Context.MODE_PRIVATE)

    fun load(ctx: Context, id: Int): Style {
        val d = Style()
        val p = sp(ctx)
        return Style(
            text = p.getInt("text2_$id", d.text),
            clock = p.getInt("clock_$id", d.clock),
            date2 = p.getInt("date2_$id", d.date2),
            accent = p.getInt("accent2_$id", d.accent),
            next = p.getInt("next_$id", d.next),
            bg = p.getInt("bg_$id", d.bg),
            bgImage = p.getBoolean("bgImage_$id", d.bgImage),
            imgAlpha = p.getInt("imgAlpha_$id", d.imgAlpha),
            bgAlpha = p.getInt("bgAlpha_$id", d.bgAlpha),
            clockScale = p.getInt("clockScale_$id", d.clockScale),
            scale = p.getInt("scale_$id", d.scale),
            zone = p.getString("zone_$id", d.zone) ?: "",
        )
    }

    fun save(ctx: Context, id: Int, s: Style) {
        sp(ctx).edit()
            .putInt("text2_$id", s.text)
            .putInt("clock_$id", s.clock)
            .putInt("date2_$id", s.date2)
            .putInt("accent2_$id", s.accent)
            .putInt("next_$id", s.next)
            .putInt("bg_$id", s.bg)
            .putBoolean("bgImage_$id", s.bgImage)
            .putInt("imgAlpha_$id", s.imgAlpha)
            .putInt("bgAlpha_$id", s.bgAlpha)
            .putInt("clockScale_$id", s.clockScale)
            .putInt("scale_$id", s.scale)
            .putString("zone_$id", s.zone)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        sp(ctx).edit()
            .remove("text_$id").remove("text2_$id").remove("clock_$id").remove("date2_$id").remove("accent_$id")
            .remove("accent2_$id").remove("next_$id").remove("bg_$id")
            .remove("bgAlpha_$id").remove("bgImage_$id").remove("imgAlpha_$id").remove("scale_$id").remove("clockScale_$id").remove("zone_$id")
            .apply()
    }
}
