package com.example.jawiclock

import android.content.Context
import android.graphics.Color

data class Style(
    val text: Int = Color.WHITE,                    // warna masa & tarikh
    val date2: Int = Color.WHITE,                   // warna tarikh rumi
    val accent: Int = Color.parseColor("#E6C86E"),  // warna bismillah & waktu
    val bg: Int = Color.parseColor("#0B3D2E"),      // warna latar
    val bgAlpha: Int = 0,                           // 0 = lutsinar, 100 = pekat
    val scale: Int = 100,                           // saiz tulisan, peratus
    val zone: String = "",                          // kod zon JAKIM, kosong = tiada waktu solat
)

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("jawi_style", Context.MODE_PRIVATE)

    fun load(ctx: Context, id: Int): Style {
        val d = Style()
        val p = sp(ctx)
        return Style(
            text = p.getInt("text_$id", d.text),
            date2 = p.getInt("date2_$id", d.date2),
            accent = p.getInt("accent_$id", d.accent),
            bg = p.getInt("bg_$id", d.bg),
            bgAlpha = p.getInt("bgAlpha_$id", d.bgAlpha),
            scale = p.getInt("scale_$id", d.scale),
            zone = p.getString("zone_$id", d.zone) ?: "",
        )
    }

    fun save(ctx: Context, id: Int, s: Style) {
        sp(ctx).edit()
            .putInt("text_$id", s.text)
            .putInt("date2_$id", s.date2)
            .putInt("accent_$id", s.accent)
            .putInt("bg_$id", s.bg)
            .putInt("bgAlpha_$id", s.bgAlpha)
            .putInt("scale_$id", s.scale)
            .putString("zone_$id", s.zone)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        sp(ctx).edit()
            .remove("text_$id").remove("date2_$id").remove("accent_$id").remove("bg_$id")
            .remove("bgAlpha_$id").remove("scale_$id").remove("zone_$id")
            .apply()
    }
}
