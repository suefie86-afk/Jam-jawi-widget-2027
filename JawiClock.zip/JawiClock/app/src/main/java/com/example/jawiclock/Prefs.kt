package com.example.jawiclock

import android.content.Context
import android.graphics.Color

data class Style(
    val text: Int = Color.WHITE,                    // putih: jam & waktu solat
    val clock: Int = Color.parseColor("#FFE600"),   // warna jam besar
    val date2: Int = Color.WHITE,                   // warna tarikh rumi
    val accent: Int = Color.parseColor("#E6C86E"),  // emas: bismillah, tarikh Jawi & nama waktu
    val next: Int = Color.parseColor("#39FF14"),    // hijau neon: waktu solat seterusnya
    val bg: Int = Color.parseColor("#0B3D2E"),      // warna latar
    val bgImage: Boolean = false,                   // guna gambar dari telefon sebagai latar
    val imgAlpha: Int = 100,                        // kelegapan gambar latar, peratus
    val bgAlpha: Int = 0,                           // 0 = lutsinar, 100 = pekat
    val clockScale: Int = 100,                      // saiz jam besar sahaja, peratus
    val nameScale: Int = 100,                       // saiz nama waktu solat, peratus
    val timeScale: Int = 100,                       // saiz jam waktu solat, peratus
    val scale: Int = 100,                           // saiz tulisan, peratus
    val zone: String = "",                          // kod zon JAKIM, kosong = tiada waktu solat
    val frameEnabled: Boolean = false,              // kotak sekeliling widget: off = kekal reka bentuk asal
    val frameColor: Int = Color.parseColor("#E6C86E"), // warna kotak sekeliling, lalai emas sama dengan accent
    val sunMoonEnabled: Boolean = true,             // ikon matahari (7pg-7mlm) / bulan sabit (mlm) sebelah jam besar
    val gapTimePeriod: Int = 2,                     // jarak jam besar ke jam Rumi (baris مالم / 7:18 PM), dp
    val gapPeriodLoc: Int = 2,                      // jarak jam Rumi ke Melaka, dp
    val gapLocDate: Int = 4,                        // jarak Melaka ke tarikh Hijri, dp
    val gapDateDate2: Int = 1,                      // jarak tarikh Hijri ke tarikh Rumi, dp
    val compact: Boolean = false,                   // padatkan widget: kurangkan jarak menegak antara elemen
    // Warna setiap elemen berasingan (tap-to-edit di preview). Lalai ikut warna lama supaya
    // widget sedia ada tidak berubah rupa: yang dulu emas ikut accent, yang dulu putih ikut text.
    val bismillah: Int = Color.parseColor("#E6C86E"), // warna Bismillah
    val period: Int = Color.parseColor("#E6C86E"),  // warna tulisan siang / malam (cth مالم)
    val loc: Int = Color.parseColor("#E6C86E"),     // warna nama lokasi
    val hijri: Int = Color.parseColor("#E6C86E"),   // warna tarikh Hijrah
    val prayerName: Int = Color.parseColor("#E6C86E"), // warna nama waktu solat
    val prayerTime: Int = Color.WHITE,              // warna angka waktu solat
    val divider: Int = Color.parseColor("#E6C86E"), // warna garisan pemisah & ornamen
)

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("jawi_style", Context.MODE_PRIVATE)

    private const val LAST = -1 // salinan tetapan widget terakhir yang dipadam

    fun exists(ctx: Context, id: Int) = sp(ctx).contains("scale_$id")
    fun keepLast(ctx: Context, id: Int) { if (exists(ctx, id)) save(ctx, LAST, load(ctx, id)) }
    fun hasLast(ctx: Context) = exists(ctx, LAST)
    fun loadLast(ctx: Context) = load(ctx, LAST)

    fun load(ctx: Context, id: Int): Style {
        val d = Style()
        val p = sp(ctx)
        // Warna lama sebagai lalai migrasi: elemen yang dulu emas ikut accent semasa,
        // elemen yang dulu putih ikut text semasa — supaya widget lama kekal rupanya.
        val accentNow = p.getInt("accent2_$id", d.accent)
        val textNow = p.getInt("text2_$id", d.text)
        return Style(
            text = p.getInt("text2_$id", d.text),
            clock = p.getInt("clock_$id", d.clock),
            date2 = p.getInt("date2_$id", d.date2),
            accent = p.getInt("accent2_$id", d.accent),
            next = p.getInt("next_$id", d.next),
            bg = p.getInt("bg_$id", d.bg),
            bgImage = p.getBoolean("bgImage_$id", d.bgImage),
            imgAlpha = p.getInt("imgAlpha_$id", d.imgAlpha),
            bgAlpha = p.getInt("bgAlpha_$id", d.bgAlpha),
            clockScale = p.getInt("clockScale_$id", d.clockScale),
            nameScale = p.getInt("nameScale_$id", d.nameScale),
            timeScale = p.getInt("timeScale_$id", d.timeScale),
            scale = p.getInt("scale_$id", d.scale),
            zone = p.getString("zone_$id", d.zone) ?: "",
            frameEnabled = p.getBoolean("frameEnabled_$id", d.frameEnabled),
            frameColor = p.getInt("frameColor_$id", d.frameColor),
            sunMoonEnabled = p.getBoolean("sunMoonEnabled_$id", d.sunMoonEnabled),
            gapTimePeriod = p.getInt("gapTimePeriod_$id", d.gapTimePeriod),
            gapPeriodLoc = p.getInt("gapPeriodLoc_$id", d.gapPeriodLoc),
            gapLocDate = p.getInt("gapLocDate_$id", d.gapLocDate),
            gapDateDate2 = p.getInt("gapDateDate2_$id", d.gapDateDate2),
            compact = p.getBoolean("compact_$id", d.compact),
            bismillah = p.getInt("bismillah_$id", accentNow),
            period = p.getInt("period_$id", accentNow),
            loc = p.getInt("loc_$id", accentNow),
            hijri = p.getInt("hijri_$id", accentNow),
            prayerName = p.getInt("prayerName_$id", accentNow),
            prayerTime = p.getInt("prayerTime_$id", textNow),
            divider = p.getInt("divider_$id", accentNow),
        )
    }

    fun save(ctx: Context, id: Int, s: Style) {
        sp(ctx).edit()
            .putInt("text2_$id", s.text)
            .putInt("clock_$id", s.clock)
            .putInt("date2_$id", s.date2)
            .putInt("accent2_$id", s.accent)
            .putInt("next_$id", s.next)
            .putInt("bg_$id", s.bg)
            .putBoolean("bgImage_$id", s.bgImage)
            .putInt("imgAlpha_$id", s.imgAlpha)
            .putInt("bgAlpha_$id", s.bgAlpha)
            .putInt("clockScale_$id", s.clockScale)
            .putInt("nameScale_$id", s.nameScale)
            .putInt("timeScale_$id", s.timeScale)
            .putInt("scale_$id", s.scale)
            .putString("zone_$id", s.zone)
            .putBoolean("frameEnabled_$id", s.frameEnabled)
            .putInt("frameColor_$id", s.frameColor)
            .putBoolean("sunMoonEnabled_$id", s.sunMoonEnabled)
            .putInt("gapTimePeriod_$id", s.gapTimePeriod)
            .putInt("gapPeriodLoc_$id", s.gapPeriodLoc)
            .putInt("gapLocDate_$id", s.gapLocDate)
            .putInt("gapDateDate2_$id", s.gapDateDate2)
            .putBoolean("compact_$id", s.compact)
            .putInt("bismillah_$id", s.bismillah)
            .putInt("period_$id", s.period)
            .putInt("loc_$id", s.loc)
            .putInt("hijri_$id", s.hijri)
            .putInt("prayerName_$id", s.prayerName)
            .putInt("prayerTime_$id", s.prayerTime)
            .putInt("divider_$id", s.divider)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        sp(ctx).edit()
            .remove("text_$id").remove("text2_$id").remove("clock_$id").remove("date2_$id").remove("accent_$id")
            .remove("accent2_$id").remove("next_$id").remove("bg_$id")
            .remove("bgAlpha_$id").remove("bgImage_$id").remove("imgAlpha_$id").remove("scale_$id").remove("clockScale_$id").remove("nameScale_$id").remove("timeScale_$id").remove("zone_$id").remove("frameEnabled_$id").remove("frameColor_$id").remove("sunMoonEnabled_$id").remove("gapTimePeriod_$id").remove("gapPeriodLoc_$id").remove("gapLocDate_$id").remove("gapDateDate2_$id").remove("compact_$id").remove("bismillah_$id").remove("period_$id").remove("loc_$id").remove("hijri_$id").remove("prayerName_$id").remove("prayerTime_$id").remove("divider_$id")
            .apply()
    }
}
