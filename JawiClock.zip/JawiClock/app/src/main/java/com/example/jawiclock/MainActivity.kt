package com.example.jawiclock

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notif.askPermission(this)
        JawiWidget.updateAll(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Jam Jawi By Dienz"
            textSize = 24f
            setPadding(0, 0, 0, dp(12))
        })
        root.addView(TextView(this).apply {
            text = "Cara tambah widget:\n" +
                "1. Tekan lama pada skrin utama\n" +
                "2. Pilih ‘Widget’\n" +
                "3. Cari ‘Jam Jawi By Dienz’ dan seret ke skrin utama\n" +
                "4. Pilih warna dan saiz, kemudian tekan Simpan\n\n" +
                "Tekan widget: kemas kini waktu solat.\n" +
                "Tekan jam besar: buka app Jam.\n" +
                "Untuk ubah tetapan: tekan lama widget, kemudian ikon pensel.\n\n" +
                "Nota: PIN melindungi tetapan aplikasi sahaja. PIN tidak boleh menghalang launcher daripada membuang widget."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = if (PinPrefs.isEnabled(this@MainActivity)) "Tukar PIN tetapan" else "Tetapkan PIN tetapan"
            setOnClickListener { showSetPinDialog() }
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            topMargin = dp(20)
        })
        if (PinPrefs.isEnabled(this)) {
            root.addView(Button(this).apply {
                text = "Matikan PIN"
                setOnClickListener { showDisablePinDialog() }
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(root)
    }

    private fun pinInput(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        setSingleLine(true)
    }

    private fun showSetPinDialog() {
        val existingPin = pinInput("PIN semasa")
        val newPin = pinInput("PIN baharu (4–8 angka)")
        val confirmPin = pinInput("Ulang PIN baharu")
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            if (PinPrefs.isEnabled(this@MainActivity)) addView(existingPin)
            addView(newPin)
            addView(confirmPin)
        }
        AlertDialog.Builder(this)
            .setTitle("Keselamatan tetapan")
            .setMessage("PIN diperlukan sebelum tetapan widget boleh diubah.")
            .setView(content)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val old = existingPin.text.toString()
                        val pin = newPin.text.toString()
                        when {
                            PinPrefs.isEnabled(this) && !PinPrefs.verify(this, old) ->
                                existingPin.error = "PIN semasa salah"
                            !pin.matches(Regex("\\d{4,8}")) ->
                                newPin.error = "Masukkan 4 hingga 8 angka"
                            pin != confirmPin.text.toString() ->
                                confirmPin.error = "PIN tidak sama"
                            else -> {
                                PinPrefs.set(this, pin)
                                Toast.makeText(this, "PIN tetapan berjaya disimpan", Toast.LENGTH_LONG).show()
                                dialog.dismiss()
                                recreate()
                            }
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun showDisablePinDialog() {
        val pin = pinInput("Masukkan PIN semasa")
        AlertDialog.Builder(this)
            .setTitle("Matikan PIN")
            .setView(pin)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Matikan", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        if (PinPrefs.verify(this, pin.text.toString())) {
                            PinPrefs.clear(this)
                            Toast.makeText(this, "PIN tetapan dimatikan", Toast.LENGTH_SHORT).show()
                            dialog.dismiss()
                            recreate()
                        } else pin.error = "PIN salah"
                    }
                }
                dialog.show()
            }
    }
}
