package com.example.jawiclock

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }
        box.addView(
            TextView(this).apply {
                text = "Jam Jawi By Dienz\n\nCara tambah widget:\n" +
                    "1. Tekan lama pada skrin utama\n" +
                    "2. Pilih \"Widget\"\n" +
                    "3. Cari \"Jam Jawi By Dienz\" dan seret ke skrin utama\n" +
                    "4. Pilih warna dan saiz, kemudian tekan Simpan\n\n" +
                    "Tekan widget: kemas kini waktu solat terus.\n" +
                    "Tekan jam besar: buka app Jam.\n" +
                    "Nak ubah tetapan: tekan lama widget tu, kemudian tekan ikon pensel."
                textSize = 18f
            },
        )
        // Azan lambat / tak bunyi bila telefon tidur selalunya sebab penjimat bateri (terutama MIUI)
        // sekat penggera app. Minta sistem kecualikan app ni supaya penggera solat tepat waktu.
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            box.addView(
                Button(this).apply {
                    text = "Benarkan azan tepat waktu (matikan penjimat bateri untuk app ni)"
                    setOnClickListener {
                        try {
                            startActivity(
                                Intent(
                                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                    Uri.parse("package:$packageName"),
                                ),
                            )
                        } catch (_: Exception) {
                            Toast.makeText(
                                this@MainActivity,
                                "Buka sendiri: Setting > Apps > Jam Jawi > Battery > No restrictions",
                                Toast.LENGTH_LONG,
                            ).show()
                        }
                    }
                },
            )
        }
        // Kalau app pernah ralat (cth widget hilang), papar butiran supaya boleh disalin dan dihantar
        val log = CrashLog.read(this)
        if (log != null) {
            box.addView(
                TextView(this).apply {
                    text = "\nRalat direkodkan:"
                    textSize = 16f
                    setPadding(0, 24, 0, 8)
                },
            )
            box.addView(
                TextView(this).apply {
                    text = log
                    textSize = 11f
                    setTextIsSelectable(true)
                },
            )
            box.addView(
                Button(this).apply {
                    text = "Salin ralat"
                    setOnClickListener {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("ralat Jam Jawi", log))
                        Toast.makeText(this@MainActivity, "Disalin", Toast.LENGTH_SHORT).show()
                    }
                },
            )
            box.addView(
                Button(this).apply {
                    text = "Padam rekod ralat"
                    setOnClickListener {
                        CrashLog.clear(this@MainActivity)
                        recreate()
                    }
                },
            )
        }
        setContentView(ScrollView(this).apply { addView(box) })
        Notif.askPermission(this)
        JawiWidget.updateAll(this)
    }
}
