package com.example.jawiclock

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = "Jam Jawi By Dienz\n\nCara tambah widget:\n" +
                "1. Tekan lama pada skrin utama\n" +
                "2. Pilih \"Widget\"\n" +
                "3. Cari \"Jam Jawi By Dienz\" dan seret ke skrin utama\n" +
                "4. Pilih warna dan saiz, kemudian tekan Simpan\n\n" +
                "Nak ubah kemudian: tekan lama widget tu, kemudian tekan ikon pensel."
            textSize = 18f
            setPadding(48, 120, 48, 48)
        }
        setContentView(tv)
        JawiWidget.updateAll(this)
    }
}
