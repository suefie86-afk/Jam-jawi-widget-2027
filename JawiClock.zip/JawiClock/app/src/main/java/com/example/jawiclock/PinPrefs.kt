package com.example.jawiclock

import android.content.Context
import java.security.MessageDigest

/** PIN protection for editing JawiClock settings (does not lock launcher removal). */
object PinPrefs {
    private const val FILE = "jawi_security"
    private const val KEY_PIN_HASH = "settings_pin_hash"

    private fun hash(pin: String): String = MessageDigest.getInstance("SHA-256")
        .digest(pin.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    fun isEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).contains(KEY_PIN_HASH)

    fun verify(ctx: Context, pin: String): Boolean {
        val saved = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_PIN_HASH, null)
        return saved != null && saved == hash(pin)
    }

    fun set(ctx: Context, pin: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_PIN_HASH, hash(pin)).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(KEY_PIN_HASH).apply()
    }
}
