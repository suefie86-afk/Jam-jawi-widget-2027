package com.example.jawiclock

import java.util.Calendar

object Jawi {
    private const val DIGITS = "٠١٢٣٤٥٦٧٨٩"

    // Ahad = Calendar.SUNDAY (1)
    private val days = listOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبتو")

    private val months = listOf(
        "جانواري", "فبروري", "مرچ", "أفريل", "مي", "جون",
        "جولاي", "أوڬس", "سيڤتيمبر", "أوكتوبر", "نوۏيمبر", "ديسيمبر",
    )

    // Subuh, Zohor, Asar, Maghrib, Isyak
    val prayerNames = listOf("سوبوه", "ظهر", "عصر", "مغرب", "عشاء")

    fun num(n: Int): String = n.toString().map { DIGITS[it - '0'] }.joinToString("")

    fun time(c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val m = num(c.get(Calendar.MINUTE)).padStart(2, '٠')
        return "${num(h12)}:$m"
    }

    // ڤاڬي = pagi, تڠه هاري = tengah hari, ڤتڠ = petang, مالم = malam
    fun period(c: Calendar): String = when (c.get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "ڤاڬي"
        in 12..14 -> "تڠه هاري"
        in 15..18 -> "ڤتڠ"
        else -> "مالم"
    }

    fun date(c: Calendar): String {
        val day = days[c.get(Calendar.DAY_OF_WEEK) - 1]
        val month = months[c.get(Calendar.MONTH)]
        return "$day، ${num(c.get(Calendar.DAY_OF_MONTH))} $month ${num(c.get(Calendar.YEAR))}"
    }
}
