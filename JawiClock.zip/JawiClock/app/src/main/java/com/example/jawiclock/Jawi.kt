package com.example.jawiclock

import java.util.Calendar

object Jawi {
    private const val DIGITS = "٠١٢٣٤٥٦٧٨٩"

    // Ahad = Calendar.SUNDAY (1)
    private val days = listOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبتو")

    private val months = listOf(
        "جانواري", "فبروري", "مرچ", "أفريل", "مي", "جون",
        "جولاي", "أوڬس", "سيڤتيمبر", "أوكتوبر", "نوۏيمبر", "ديسيمبر",
    )

    // Subuh, Zohor, Asar, Maghrib, Isyak
    val prayerNames = listOf("سوبوه", "ظهر", "عصر", "مغرب", "عشاء")

    fun num(n: Int): String = n.toString().map { DIGITS[it - '0'] }.joinToString("")

    fun time(c: Calendar): String {
        val h = c.get(Calendar.HOUR_OF_DAY)
        val h12 = if (h % 12 == 0) 12 else h % 12
        val m = num(c.get(Calendar.MINUTE)).padStart(2, '٠')
        return "${num(h12)}:$m"
    }

    // ڤاڬي = pagi, تڠه هاري = tengah hari, ڤتڠ = petang, مالم = malam
    fun period(c: Calendar): String = when (c.get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "ڤاڬي"
        in 12..14 -> "تڠه هاري"
        in 15..18 -> "ڤتڠ"
        else -> "مالم"
    }

    fun date(c: Calendar): String {
        val day = days[c.get(Calendar.DAY_OF_WEEK) - 1]
        val month = months[c.get(Calendar.MONTH)]
        return "$day، ${num(c.get(Calendar.DAY_OF_MONTH))} $month ${num(c.get(Calendar.YEAR))}"
    }

    private val monthsHijri = listOf(
        "محرم", "صفر", "ربيع الاول", "ربيع الاخر", "جمادى الاول", "جمادى الاخر",
        "رجب", "شعبان", "رمضان", "شوال", "ذوالقعدة", "ذوالحجة",
    )

    /** Tarikh Hijri dikira dalam telefon (Umm al-Qura), digunakan bila data JAKIM belum ada. */
    private fun hijriOffline(c: Calendar): Triple<Int, Int, Int> {
        val ic = android.icu.util.IslamicCalendar()
        ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA)
        ic.timeInMillis = c.timeInMillis
        return Triple(
            ic.get(android.icu.util.Calendar.YEAR),
            ic.get(android.icu.util.Calendar.MONTH) + 1,
            ic.get(android.icu.util.Calendar.DAY_OF_MONTH),
        )
    }

    /** Tambah satu hari pada tarikh Hijri (hari Islam bertukar waktu Maghrib). */
    private fun nextHijriDay(t: Triple<Int, Int, Int>): Triple<Int, Int, Int> {
        val ic = android.icu.util.IslamicCalendar()
        ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA)
        ic.set(android.icu.util.Calendar.YEAR, t.first)
        ic.set(android.icu.util.Calendar.MONTH, t.second - 1)
        ic.set(android.icu.util.Calendar.DAY_OF_MONTH, t.third)
        ic.add(android.icu.util.Calendar.DAY_OF_MONTH, 1)
        return Triple(
            ic.get(android.icu.util.Calendar.YEAR),
            ic.get(android.icu.util.Calendar.MONTH) + 1,
            ic.get(android.icu.util.Calendar.DAY_OF_MONTH),
        )
    }

    /**
     * Tarikh Islam dalam Jawi, cth: أحد، ١٠ ربيع الاخر ١٤٤٨.
     * [jakim] = tarikh Hijri rasmi dari JAKIM (tahun, bulan, hari); kalau null guna pengiraan telefon.
     * [afterMaghrib] = sudah masuk Maghrib: hari Islam sudah bertukar, jadi tarikh dan nama hari
     * dimajukan sehari (malam Jumaat dipaparkan sebagai hari Jumaat).
     */
    fun dateHijri(c: Calendar, jakim: Triple<Int, Int, Int>?, afterMaghrib: Boolean = false): String {
        val base = jakim ?: hijriOffline(c)
        val (y, m, d) = if (afterMaghrib) nextHijriDay(base) else base
        val dayIdx = (c.get(Calendar.DAY_OF_WEEK) - 1 + (if (afterMaghrib) 1 else 0)) % 7
        return "${days[dayIdx]}، ${num(d)} ${monthsHijri[(m - 1).coerceIn(0, 11)]} ${num(y)}"
    }

    private val daysMy = listOf("Ahad", "Isnin", "Selasa", "Rabu", "Khamis", "Jumaat", "Sabtu")
    private val monthsMy = listOf(
        "Januari", "Februari", "Mac", "April", "Mei", "Jun",
        "Julai", "Ogos", "September", "Oktober", "November", "Disember",
    )

    /** Tarikh biasa (rumi), cth: Ahad, 25 Oktober 2026 */
    fun dateLatin(c: Calendar): String =
        "${daysMy[c.get(Calendar.DAY_OF_WEEK) - 1]}, ${c.get(Calendar.DAY_OF_MONTH)} " +
            "${monthsMy[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)}"
}
