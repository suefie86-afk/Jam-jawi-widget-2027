package com.example.jawiclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Mainkan azan melalui saluran ALARM, jadi tetap berbunyi walaupun telefon mod senyap
 * (ikut kelantangan alarm). Berjalan sebagai foreground service supaya tidak dimatikan
 * sebelum azan habis. Notifikasi ada butang "Henti azan".
 */
class AzanService : Service() {
    companion object {
        private const val ACTION_STOP = "com.example.jawiclock.AZAN_STOP"
        private const val CHANNEL = "azan_main"
        private const val NOTIF_ID = 3000

        /** Benar bila azan sedang dimainkan (digunakan widget untuk "tekan = henti azan"). */
        @Volatile
        var isPlaying = false
            private set

        /** Laras kelantangan alarm ikut tetapan azan (kalau azan sedang main, terus berkesan). */
        fun applyVolume(ctx: Context) {
            if (!isPlaying) return
            setAlarmVolume(ctx)
        }

        private fun setAlarmVolume(ctx: Context): Int {
            val am = ctx.getSystemService(AudioManager::class.java)
            val prev = am.getStreamVolume(AudioManager.STREAM_ALARM)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val target = Math.round(max * Azan.volume(ctx) / 100f).coerceIn(1, max)
            try {
                am.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
            } catch (_: SecurityException) {
            }
            return prev
        }

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, AzanService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AzanService::class.java))
        }
    }

    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private var prevVolume = -1 // kelantangan alarm sebelum azan, untuk dipulihkan

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        play()
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Azan", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Notifikasi semasa azan dimainkan"
                    enableVibration(false)
                    setSound(null, null)
                },
            )
        }
        val stopPi = PendingIntent.getService(
            this, 3,
            Intent(this, AzanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Azan sedang dimainkan")
            .setContentText("Tekan notifikasi ini untuk henti azan")
            .setContentIntent(stopPi)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat_solat), "Henti azan", stopPi,
                ).build(),
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun play() {
        releasePlayer()
        if (!Azan.hasFile(this)) {
            stopSelf()
            return
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val am = getSystemService(AudioManager::class.java)
        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(attrs)
            .build()
            .also { am.requestAudioFocus(it) }
        // Kelantangan azan ikut tetapan app (saluran alarm), dipulihkan selepas azan habis
        val before = setAlarmVolume(this)
        if (prevVolume < 0) prevVolume = before
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(Azan.file(this@AzanService).absolutePath)
                setWakeMode(this@AzanService, PowerManager.PARTIAL_WAKE_LOCK)
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepare()
                start()
            }
            isPlaying = true
            JawiWidget.updateAll(applicationContext) // widget: sentuh = henti azan
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun releasePlayer() {
        player?.let {
            try { if (it.isPlaying) it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }

    override fun onDestroy() {
        releasePlayer()
        if (prevVolume >= 0) {
            try {
                getSystemService(AudioManager::class.java).setStreamVolume(AudioManager.STREAM_ALARM, prevVolume, 0)
            } catch (_: SecurityException) {
            }
            prevVolume = -1
        }
        val wasPlaying = isPlaying
        isPlaying = false
        if (wasPlaying) JawiWidget.updateAll(applicationContext)
        focus?.let { getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focus = null
        super.onDestroy()
    }
}
