package com.example.jawiclock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Mainkan azan melalui saluran ALARM, jadi tetap berbunyi walaupun telefon mod senyap
 * (ikut kelantangan alarm). Berjalan sebagai foreground service supaya tidak dimatikan
 * sebelum azan habis. Notifikasi ada butang "Henti azan".
 */
class AzanService : Service() {
    companion object {
        private const val ACTION_STOP = "com.example.jawiclock.AZAN_STOP"
        private const val CHANNEL = "azan_main"
        private const val NOTIF_ID = 3000

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, AzanService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AzanService::class.java))
        }
    }

    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        play()
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Azan", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Notifikasi semasa azan dimainkan"
                    enableVibration(false)
                    setSound(null, null)
                },
            )
        }
        val stopPi = PendingIntent.getService(
            this, 3,
            Intent(this, AzanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Azan sedang dimainkan")
            .setContentText("Tekan Henti azan untuk berhenti")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat_solat), "Henti azan", stopPi,
                ).build(),
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun play() {
        releasePlayer()
        if (!Azan.hasFile(this)) {
            stopSelf()
            return
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val am = getSystemService(AudioManager::class.java)
        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(attrs)
            .build()
            .also { am.requestAudioFocus(it) }
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(Azan.file(this@AzanService).absolutePath)
                setWakeMode(this@AzanService, PowerManager.PARTIAL_WAKE_LOCK)
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepare()
                start()
            }
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun releasePlayer() {
        player?.let {
            try { if (it.isPlaying) it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
    }

    override fun onDestroy() {
        releasePlayer()
        focus?.let { getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focus = null
        super.onDestroy()
    }
}
