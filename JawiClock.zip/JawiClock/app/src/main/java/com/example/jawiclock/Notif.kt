package com.example.jawiclock

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Notifikasi: masuk waktu solat, dan pemulihan widget yang terpadam. */
object Notif {
    private const val CH_SOLAT = "waktu_solat"
    private const val CH_RESTORE = "pasang_semula"
    private const val ID_PRAYER = 1000
    private const val ID_RESTORE = 2000
    private val NAMES = listOf("Subuh", "Zohor", "Asar", "Maghrib", "Isyak")

    private fun ensureChannel(
        ctx: Context, id: String, name: String, desc: String, importance: Int,
    ) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) != null) return
        val ch = NotificationChannel(id, name, importance).apply {
            description = desc
            enableVibration(false) // getaran waktu solat dibuat oleh widget
        }
        nm.createNotificationChannel(ch)
    }

    const val ACTION_PRAYER_DISMISSED = "com.example.jawiclock.PRAYER_DISMISSED"
    private const val CH_SOLAT_SENYAP = "waktu_solat_senyap"

    private fun nsp(ctx: Context) = ctx.getSharedPreferences("jawi_notif", Context.MODE_PRIVATE)

    private fun buildPrayer(ctx: Context, index: Int, channel: String): Notification {
        val name = NAMES.getOrElse(index) { "solat" }
        // Bila pengguna leret/buang notifikasi ini, widget dimaklumkan supaya tak dipaparkan semula
        val dismissPi = PendingIntent.getBroadcast(
            ctx, 5,
            Intent(ctx, JawiWidget::class.java).setAction(ACTION_PRAYER_DISMISSED),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Jam Jawi")
            .setContentText("Eh, dah masuk waktu $name")
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(false)
            .setDeleteIntent(dismissPi)
            .build()
    }

    fun notifyPrayer(ctx: Context, index: Int) {
        ensureChannel(ctx, CH_SOLAT, "Waktu solat", "Pemberitahuan bila masuk waktu solat", NotificationManager.IMPORTANCE_HIGH)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        // Satu notifikasi sahaja: waktu baru menggantikan yang lama (tak bertimbun).
        // Buang sisa notifikasi per-waktu versi lama.
        for (i in 1..4) nm.cancel(ID_PRAYER + i)
        nm.notify(ID_PRAYER, buildPrayer(ctx, index, CH_SOLAT))
        nsp(ctx).edit()
            .putInt("shown", index)
            .putBoolean("dismissed", false)
            .putLong("at", System.currentTimeMillis())
            .apply()
    }

    /** Pengguna meleret notifikasi waktu solat: jangan paparkan semula. */
    fun markDismissed(ctx: Context) {
        nsp(ctx).edit().putBoolean("dismissed", true).apply()
    }

    /**
     * Dipanggil setiap minit. Kalau notifikasi waktu solat terakhir belum dileret tetapi sudah
     * hilang (dibuang oleh sistem/pelancar), paparkan semula secara senyap supaya ia kekal
     * sehingga dileret atau sehingga waktu solat seterusnya menggantikannya.
     */
    fun keepAlive(ctx: Context) {
        val sp = nsp(ctx)
        val shown = sp.getInt("shown", -1)
        if (shown < 0 || sp.getBoolean("dismissed", true)) return
        // Beri masa notifikasi baru dipaparkan sistem (jangan ganti terus dengan versi senyap)
        if (System.currentTimeMillis() - sp.getLong("at", 0L) < 3 * 60_000L) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        if (nm.activeNotifications.any { it.id == ID_PRAYER }) return
        ensureChannel(ctx, CH_SOLAT_SENYAP, "Waktu solat (senyap)", "Paparan semula notifikasi waktu solat tanpa bunyi", NotificationManager.IMPORTANCE_LOW)
        nm.notify(ID_PRAYER, buildPrayer(ctx, shown, CH_SOLAT_SENYAP))
    }

    /** Widget terpadam dari skrin: tawarkan pasang semula dengan satu tekan. */
    fun notifyRestore(ctx: Context) {
        ensureChannel(ctx, CH_RESTORE, "Pasang semula widget", "Muncul bila widget Jam Jawi terpadam", NotificationManager.IMPORTANCE_DEFAULT)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        val pi = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, RestoreActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(ctx, CH_RESTORE)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Jam Jawi terpadam")
            .setContentText("Tekan di sini untuk pasang semula widget")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(ID_RESTORE, n)
    }

    fun cancelRestore(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_RESTORE)
    }

    /** Android 13+ perlu kebenaran notifikasi. Dipanggil bila app/tetapan dibuka. */
    fun askPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 33 &&
            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2002)
        }
    }
}
