package com.example.jawiclock

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Notifikasi: masuk waktu solat, dan pemulihan widget yang terpadam. */
object Notif {
    private const val CH_SOLAT = "waktu_solat"
    private const val CH_RESTORE = "pasang_semula"
    private const val ID_RESTORE = 2000
    private val NAMES = listOf("Subuh", "Zohor", "Asar", "Maghrib", "Isyak")

    private fun ensureChannel(
        ctx: Context, id: String, name: String, desc: String, importance: Int,
    ) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) != null) return
        val ch = NotificationChannel(id, name, importance).apply {
            description = desc
            enableVibration(false) // getaran waktu solat dibuat oleh widget
        }
        nm.createNotificationChannel(ch)
    }

    fun notifyPrayer(ctx: Context, index: Int) {
        ensureChannel(ctx, CH_SOLAT, "Waktu solat", "Pemberitahuan bila masuk waktu solat", NotificationManager.IMPORTANCE_HIGH)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        val name = NAMES.getOrElse(index) { "solat" }
        val n = Notification.Builder(ctx, CH_SOLAT)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Jam Jawi")
            .setContentText("Eh, dah masuk waktu $name")
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .build()
        nm.notify(1000 + index, n)
    }

    /** Widget terpadam dari skrin: tawarkan pasang semula dengan satu tekan. */
    fun notifyRestore(ctx: Context) {
        ensureChannel(ctx, CH_RESTORE, "Pasang semula widget", "Muncul bila widget Jam Jawi terpadam", NotificationManager.IMPORTANCE_DEFAULT)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        val pi = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, RestoreActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(ctx, CH_RESTORE)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Jam Jawi terpadam")
            .setContentText("Tekan di sini untuk pasang semula widget")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(ID_RESTORE, n)
    }

    fun cancelRestore(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_RESTORE)
    }

    /** Android 13+ perlu kebenaran notifikasi. Dipanggil bila app/tetapan dibuka. */
    fun askPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 33 &&
            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2002)
        }
    }
}
