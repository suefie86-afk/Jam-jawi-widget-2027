package com.example.jawiclock

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/** Notifikasi bila masuk waktu solat. Getaran dikendalikan berasingan (lihat JawiWidget.vibrate). */
object Notif {
    private const val CHANNEL = "waktu_solat"
    private val NAMES = listOf("Subuh", "Zohor", "Asar", "Maghrib", "Isyak")

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, "Waktu solat", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pemberitahuan bila masuk waktu solat"
            enableVibration(false) // getaran sudah dibuat oleh widget
        }
        nm.createNotificationChannel(ch)
    }

    fun notifyPrayer(ctx: Context, index: Int) {
        ensureChannel(ctx)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return
        val name = NAMES.getOrElse(index) { "solat" }
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_solat)
            .setContentTitle("Jam Jawi")
            .setContentText("Eh, dah masuk waktu $name")
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .build()
        nm.notify(1000 + index, n)
    }

    /** Android 13+ perlu kebenaran notifikasi. Dipanggil bila app/tetapan dibuka. */
    fun askPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 33 &&
            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2002)
        }
    }
}
